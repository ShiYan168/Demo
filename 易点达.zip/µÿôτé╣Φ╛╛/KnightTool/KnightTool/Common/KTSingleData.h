//
//  KTSingleData.h
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/12.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KTSingleData : NSObject
@property(nonatomic,assign)BOOL reachability;//判断网络连接状态
@property(nonatomic,copy)NSString *phone;
@property(nonatomic,copy)NSString *objectId;
+(KTSingleData*)sharedManager;
-(void)Logout;//退出登录
@end

NS_ASSUME_NONNULL_END
