//
//  KTSingleData.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/12.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "KTSingleData.h"

@implementation KTSingleData
+(KTSingleData*)sharedManager{
    static KTSingleData* sharedManager = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate,
                  ^{
                      sharedManager = [[self alloc]init];
                  });
    return sharedManager;
}
-(void)setPhone:(NSString *)phone{
    [UserDefaults setObject:phone forKey:@"phone"];
    [UserDefaults synchronize];
}
- (NSString*)phone{
    NSString* phone = [UserDefaults objectForKey:@"phone"];
    return phone.length>0?phone:@"";
}
-(void)setObjectId:(NSString *)objectId{
    [UserDefaults setObject:objectId forKey:@"objectId"];
    [UserDefaults synchronize];
}
-(NSString *)objectId{
    NSString* objectId = [UserDefaults objectForKey:@"objectId"];
    return objectId.length>0?objectId:@"";
}
//退出登录
-(void)Logout{
    //清空数据
    [UserDefaults removeObjectForKey:@"phone"];
     [UserDefaults removeObjectForKey:@"objectId"];
    [UserDefaults synchronize];
}
@end
