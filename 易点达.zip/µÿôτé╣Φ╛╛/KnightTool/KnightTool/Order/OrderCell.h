//
//  OrderCell.h
//  KnightVersion
//
//  Created by ios on 2017/12/27.
//  Copyright © 2017年 ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol OrderCellDelegate
- (void)reloadViewData;
@end

@interface OrderCell : UITableViewCell
@property (nonatomic,weak) id<OrderCellDelegate>delegate;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *btnHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *btnTop;
@property (weak, nonatomic) IBOutlet UILabel *orderStatus;

@property (weak, nonatomic) IBOutlet UILabel *orderNumber;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UIButton *songda;
@property (weak, nonatomic) IBOutlet UIButton *callBtn;
@property (nonatomic,strong)AVObject *model;
@end
