//
//  MarkiCell.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/14.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "MarkiCell.h"

@implementation MarkiCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setObj:(AVObject *)obj{
    _obj = obj;
    _name.text = _obj[@"name"];
    _phone.text = _obj[@"phone"];
}
-(void)setStatusObj:(AVObject *)statusObj{
    _statusObj = statusObj;
    if([_statusObj[@"orderStatus"] isEqualToString:@"3"]){
        _marik.text = @"已送达";
    }
}
@end
