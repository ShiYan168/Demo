//
//  OrderDetailController.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/13.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "OrderDetailController.h"
#import "OnumberCell.h"
#import "OrderAddressCell.h"
#import "GoodsCell.h"
#import "OrderPriceCell.h"
#import "MarkiCell.h"
#import "OrderButtonCell.h"

@interface OrderDetailController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView* tabView;
@property(nonatomic,strong)NSMutableArray* mutArr;
@end

@implementation OrderDetailController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.tabView reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setKTNavTitle:@"订单详情"];
    [self setNavgationLeftItemBtn];
    self.tabView = [[UITableView alloc]init];
    self.tabView.scrollsToTop = YES;
    self.tabView.showsVerticalScrollIndicator = NO;
    self.tabView.rowHeight = UITableViewAutomaticDimension;
    self.tabView.estimatedRowHeight = 100;
    self.tabView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tabView.tableFooterView = [UIImageView new];
    self.tabView.delegate = self;
    self.tabView.dataSource = self;
    [self.view addSubview:self.tabView];
    [self.tabView mas_makeConstraints:^(MASConstraintMaker *make){
        make.edges.equalTo(self.view).with.insets(UIEdgeInsetsMake(0, 0, 0, 0));
    }];
    _mutArr = [[NSMutableArray alloc] init];
    [_mutArr addObjectsFromArray:self.obj[@"goodsArray"]];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 4;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==0) {
        return _obj?2:0;
    }else if (section==1){
        return _mutArr.count;
    }else if (section==2){
        return 1;
    }else if (section==3){
        if ([_obj[@"orderStatus"] isEqualToString:@"2"]) {
            return 2;
        }
        return 1;
    }
    return 0;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    switch(indexPath.section){
        case 0:
        {
            if (indexPath.row==0) {
                OnumberCell *cell = [tableView dequeueReusableCellWithIdentifier:@"OnumberCell"];
                if (!cell){
                    cell= [[[NSBundle  mainBundle]  loadNibNamed:@"OnumberCell" owner:self options:nil]  lastObject];
                    [tableView registerNib:[UINib nibWithNibName:@"OnumberCell" bundle:nil] forCellReuseIdentifier:@"OnumberCell"];
                }
                cell.obj = self.obj;
                return cell;
            }
            OrderAddressCell *cell = [tableView dequeueReusableCellWithIdentifier:@"OrderAddressCell"];
            if (!cell){
                cell= [[[NSBundle  mainBundle]  loadNibNamed:@"OrderAddressCell" owner:self options:nil]  lastObject];
                [tableView registerNib:[UINib nibWithNibName:@"OrderAddressCell" bundle:nil] forCellReuseIdentifier:@"OrderAddressCell"];
            }
            cell.obj = self.obj;
            return cell;
           
        }
            break;
        case 1:
        {
            GoodsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"GoodsCell"];
            if (!cell){
                cell= [[[NSBundle  mainBundle]  loadNibNamed:@"GoodsCell" owner:self options:nil]  lastObject];
                [tableView registerNib:[UINib nibWithNibName:@"GoodsCell" bundle:nil] forCellReuseIdentifier:@"GoodsCell"];
            }
            cell.goodsDic = self.mutArr[indexPath.row];
            return cell;
        }
            break;
        case 2:
        {
            OrderPriceCell *cell = [tableView dequeueReusableCellWithIdentifier:@"OrderPriceCell"];
            if (!cell){
                cell= [[[NSBundle  mainBundle]  loadNibNamed:@"OrderPriceCell" owner:self options:nil]  lastObject];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;//选中状态下颜色为透明色
                [tableView registerNib:[UINib nibWithNibName:@"OrderPriceCell" bundle:nil] forCellReuseIdentifier:@"OrderPriceCell"];
            }
            cell.obj = self.obj;
            return cell;
        }
            break;
        case 3:
        {
            if([_obj[@"orderStatus"] isEqualToString:@"1"]){
                OrderButtonCell *cell = [tableView dequeueReusableCellWithIdentifier:@"OrderButtonCell"];
                if (!cell){
                    cell= [[[NSBundle  mainBundle]  loadNibNamed:@"OrderButtonCell" owner:self options:nil]  lastObject];
                    cell.selectionStyle = UITableViewCellSelectionStyleNone;//选中状态下颜色为透明色
                    [tableView registerNib:[UINib nibWithNibName:@"OrderButtonCell" bundle:nil] forCellReuseIdentifier:@"OrderButtonCell"];
                }
                cell.model = self.obj;
                
                return cell;
            }else if([_obj[@"orderStatus"] isEqualToString:@"2"]) {
                if (indexPath.row==0) {
                    MarkiCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MarkiCell"];
                    if (!cell){
                        cell= [[[NSBundle  mainBundle]  loadNibNamed:@"MarkiCell" owner:self options:nil]  lastObject];
                        cell.selectionStyle = UITableViewCellSelectionStyleNone;//选中状态下颜色为透明色
                        [tableView registerNib:[UINib nibWithNibName:@"MarkiCell" bundle:nil] forCellReuseIdentifier:@"MarkiCell"];
                    }
                    cell.obj = self.obj[@"marki"];
                    return cell;
                }
                OrderButtonCell *cell = [tableView dequeueReusableCellWithIdentifier:@"OrderButtonCell"];
                if (!cell){
                    cell= [[[NSBundle  mainBundle]  loadNibNamed:@"OrderButtonCell" owner:self options:nil]  lastObject];
                    cell.selectionStyle = UITableViewCellSelectionStyleNone;//选中状态下颜色为透明色
                    [tableView registerNib:[UINib nibWithNibName:@"OrderButtonCell" bundle:nil] forCellReuseIdentifier:@"OrderButtonCell"];
                }
                cell.model = self.obj;
                return cell;
            }else if([_obj[@"orderStatus"] isEqualToString:@"3"]) {
                MarkiCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MarkiCell"];
                if (!cell){
                    cell= [[[NSBundle  mainBundle]  loadNibNamed:@"MarkiCell" owner:self options:nil]  lastObject];
                    cell.selectionStyle = UITableViewCellSelectionStyleNone;//选中状态下颜色为透明色
                    [tableView registerNib:[UINib nibWithNibName:@"MarkiCell" bundle:nil] forCellReuseIdentifier:@"MarkiCell"];
                }
                cell.statusObj = self.obj;
                cell.obj = self.obj[@"marki"];
                return cell;
            }
            
        }
            break;
            
        default:
            break;
    }
    return [UITableViewCell new];
}
@end
