//
//  OrderCell.m
//  KnightVersion
//
//  Created by ios on 2017/12/27.
//  Copyright © 2017年 ios. All rights reserved.
//

#import "OrderCell.h"

@implementation OrderCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    _songda.layer.cornerRadius = 3;
    _songda.layer.borderColor = [RGB(200, 200, 200) CGColor];
    _songda.layer.borderWidth = 1;
    _callBtn.layer.cornerRadius = 3;
    _callBtn.layer.borderColor = [RGB(200, 200, 200) CGColor];
    _callBtn.layer.borderWidth = 1;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setModel:(AVObject *)model{
    _model = model;
    if([_model[@"orderStatus"] isEqualToString:@"1"]) {
        _orderStatus.text = @"待配送";
    }else if([_model[@"orderStatus"] isEqualToString:@"2"]) {
        _orderStatus.text = @"配送中";
    }else if([_model[@"orderStatus"] isEqualToString:@"3"]) {
        _orderStatus.text = @"已送达";
    }
    
    _orderNumber.text = _model[@"orderNumber"];
    _address.text = [NSString stringWithFormat:@"%@%@",_model[@"address"][@"ProvincesStr"],_model[@"address"][@"detail"]];
  NSString* statusStr =  _model[@"orderStatus"];
    if([statusStr isEqualToString:@"1"]){
        _callBtn.hidden = YES;
        _songda.hidden = NO;
        _songda.enabled = YES;
        [_songda setTitle:@"立即接单" forState:UIControlStateNormal];
        
    }else if ([statusStr isEqualToString:@"2"]){
         _callBtn.hidden = NO;
         _songda.hidden = NO;
        _songda.enabled = YES;
        [_songda setTitle:@"确认送达" forState:UIControlStateNormal];

    }else if ([statusStr isEqualToString:@"3"]){
        _callBtn.hidden = YES;
        _songda.enabled = NO;
         _songda.hidden = YES;
        [_songda setTitle:@"已送达" forState:UIControlStateNormal];
        _btnTop.constant = 0;
        _btnHeight.constant = 0;
    }
}
//联系买家
- (IBAction)callBtn:(UIButton *)sender{
    AVObject* address = _model[@"address"];
    NSMutableString *str=[[NSMutableString alloc]initWithFormat:@"tel:%@",address[@"phone"]];
//    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str] options:@{} completionHandler:^(BOOL success) {
        
    }];
}
//立即接单
- (IBAction)songDa:(UIButton *)sender{
    __weak typeof(self)wself = self;

    if ([sender.titleLabel.text isEqualToString:@"立即接单"]){
        [self showAlertTitle:@"确定接单?" handler:^(UIAlertAction *action){
            AVObject* orderObj = [AVObject objectWithClassName:@"Order" objectId:wself.model[@"objectId"]];
            AVObject* marki = [AVObject objectWithClassName:@"KTUser" objectId:[KTSingleData sharedManager].objectId];
            
            [orderObj setObject:marki forKey:@"marki"];
            [orderObj setObject:@"2" forKey:@"orderStatus"];
            [orderObj saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
                if (succeeded){
                    [wself updateCommunityOrderNums];
                    [wself showToastWithText:@"接单成功"];
                    [wself.delegate reloadViewData];
                }else{
                    [wself showToastWithText:@"接单失败"];
                }
            }];
        }];
    }else if([sender.titleLabel.text isEqualToString:@"确认送达"]){
        
        [self showAlertTitle:@"确认送达?" handler:^(UIAlertAction *action) {
            AVObject* orderObj = [AVObject objectWithClassName:@"Order" objectId:wself.model[@"objectId"]];
            [orderObj setObject:@"3" forKey:@"orderStatus"];
            [orderObj saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
                if (succeeded){
                    [wself showToastWithText:@"操作成功"];
                    [wself.delegate reloadViewData];
                }else{
                    [wself showToastWithText:@"接单失败"];
                }
            }];
        }];
    }
}
//更改小区订单数量
-(void)updateCommunityOrderNums{
    AVQuery *query = [AVQuery queryWithClassName:@"Community"];
    [query whereKey:@"communityId" equalTo:_model[@"communityId"]];
    [query whereKey:@"countyId" equalTo:_model[@"countyId"]];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error){
        if (!error) {
            if (objects.count>0) {
                AVObject* obj = [objects firstObject];
                NSInteger orderNums = [obj[@"orderNums"] integerValue];
                [obj setObject:[NSString stringWithFormat:@"%ld",--orderNums] forKey:@"orderNums"];
                [obj saveInBackground];
            }
        }
    }];
}
@end
