//
//  OrderPriceCell.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/14.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "OrderPriceCell.h"

@implementation OrderPriceCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setObj:(AVObject *)obj{
    _obj = obj;
    CGFloat weightF = [_obj[@"orderFreight"] floatValue];
    if (weightF>0) {
        _orderWeight.text = [NSString stringWithFormat:@"¥%@",_obj[@"orderFreight"]];
    }else{
        _orderWeight.text = @"满减运费";
    }
    _orderPrice.text = [NSString stringWithFormat:@"¥%@",_obj[@"orderPrice"]];
}
@end
