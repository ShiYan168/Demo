//
//  OrderAddressCell.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/14.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "OrderAddressCell.h"

@implementation OrderAddressCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setObj:(AVObject *)obj{
    _obj = obj;
    _name.text = _obj[@"address"][@"name"];
    _phone.text = _obj[@"address"][@"phone"];
    _address.text = [NSString stringWithFormat:@"%@%@",_obj[@"address"][@"ProvincesStr"],_obj[@"address"][@"detail"]];;
}
@end
