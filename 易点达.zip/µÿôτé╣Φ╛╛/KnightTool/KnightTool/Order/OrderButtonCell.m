//
//  OrderButtonCell.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/14.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "OrderButtonCell.h"

@implementation OrderButtonCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    _sendBtn.layer.cornerRadius = 3;
    _sendBtn.layer.borderColor = [RGB(200, 200, 200) CGColor];
    _sendBtn.layer.borderWidth = 1;
    _callBtn.layer.cornerRadius = 3;
    _callBtn.layer.borderColor = [RGB(200, 200, 200) CGColor];
    _callBtn.layer.borderWidth = 1;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setModel:(AVObject *)model{
    _model = model;
    
    NSString* statusStr =  _model[@"orderStatus"];
    if([statusStr isEqualToString:@"1"]){
        _callBtn.hidden = YES;
         _sendBtn.hidden = NO;
        _sendBtn.enabled = YES;
        [_sendBtn setTitle:@"立即接单" forState:UIControlStateNormal];
        
    }else if ([statusStr isEqualToString:@"2"]){
        _callBtn.hidden = NO;
        _sendBtn.hidden = NO;
        _sendBtn.enabled = YES;
        [_sendBtn setTitle:@"确认送达" forState:UIControlStateNormal];
    }else if ([statusStr isEqualToString:@"3"]){
        _callBtn.hidden = YES;
        _sendBtn.hidden = YES;
        _sendBtn.enabled = NO;
        [_sendBtn setTitle:@"已送达" forState:UIControlStateNormal];
    }
    
    
}
//联系买家
- (IBAction)callBtn:(UIButton *)sender{
    AVObject* address = _model[@"address"];
    NSMutableString *str=[[NSMutableString alloc]initWithFormat:@"tel:%@",address[@"phone"]];
    //    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str] options:@{} completionHandler:^(BOOL success) {
        
    }];
}
//立即接单
- (IBAction)songDa:(UIButton *)sender{
    __weak typeof(self)wself = self;
    
    if ([sender.titleLabel.text isEqualToString:@"立即接单"]){
        [self showAlertTitle:@"确定接单?" handler:^(UIAlertAction *action){
            AVObject* orderObj = [AVObject objectWithClassName:@"Order" objectId:wself.model[@"objectId"]];
            AVObject* marki = [AVObject objectWithClassName:@"KTUser" objectId:[KTSingleData sharedManager].objectId];
            
            [orderObj setObject:marki forKey:@"marki"];
            [orderObj setObject:@"2" forKey:@"orderStatus"];
            [orderObj saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
                if (succeeded){
                    [wself updateCommunityOrderNums];
                    [wself showToastWithText:@"接单成功"];
                    [wself.containingViewController.navigationController popViewControllerAnimated:YES];
                }else{
                    [wself showToastWithText:@"接单失败"];
                }
            }];
        }];
    }else if([sender.titleLabel.text isEqualToString:@"确认送达"]){
        
        [self showAlertTitle:@"确认送达?" handler:^(UIAlertAction *action) {
            AVObject* orderObj = [AVObject objectWithClassName:@"Order" objectId:wself.model[@"objectId"]];
            [orderObj setObject:@"3" forKey:@"orderStatus"];
            [orderObj saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
                if (succeeded){
                    [wself showToastWithText:@"操作成功"];
                    [wself.containingViewController.navigationController popViewControllerAnimated:YES];
                }else{
                    [wself showToastWithText:@"接单失败"];
                }
            }];
        }];
    }
}
//更改小区订单数量
-(void)updateCommunityOrderNums{
    AVQuery *query = [AVQuery queryWithClassName:@"Community"];
    [query whereKey:@"communityId" equalTo:_model[@"communityId"]];
    [query whereKey:@"countyId" equalTo:_model[@"countyId"]];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error){
        if (!error) {
            if (objects.count>0) {
                AVObject* obj = [objects firstObject];
                NSInteger orderNums = [obj[@"orderNums"] integerValue];
                [obj setObject:[NSString stringWithFormat:@"%ld",--orderNums] forKey:@"orderNums"];
                [obj saveInBackground];
            }
        }
    }];
}
@end
