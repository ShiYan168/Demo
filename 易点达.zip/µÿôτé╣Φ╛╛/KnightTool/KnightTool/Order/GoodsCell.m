//
//  GoodsCell.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/13.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "GoodsCell.h"

@implementation GoodsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setGoodsDic:(NSDictionary *)goodsDic{
    _goodsDic = goodsDic;
    [_goodsIcon sd_setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@", _goodsDic[@"goodsIcon"]]] placeholderImage:[UIImage imageNamed:@"placeholder"]];
    _goodsName.text = _goodsDic[@"goodsName"];
    _goodsPrice.text = [NSString stringWithFormat:@"¥%@",_goodsDic[@"goodsPrice"]];
    _goodsWeight.text = [NSString stringWithFormat:@"¥%@",_goodsDic[@"goodsWeight"]];
    _goodsNums.text = _goodsDic[@"goodsNums"];
}
@end
