//
//  GoodsCell.h
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/13.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GoodsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *goodsIcon;
@property (weak, nonatomic) IBOutlet UILabel *goodsName;
@property (weak, nonatomic) IBOutlet UILabel *goodsPrice;
@property (weak, nonatomic) IBOutlet UILabel *goodsWeight;
@property (weak, nonatomic) IBOutlet UILabel *goodsNums;
@property(nonatomic,strong)NSDictionary* goodsDic;
@end

NS_ASSUME_NONNULL_END
