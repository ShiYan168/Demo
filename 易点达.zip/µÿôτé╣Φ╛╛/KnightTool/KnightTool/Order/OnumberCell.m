//
//  OnumberCell.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/14.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "OnumberCell.h"

@implementation OnumberCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setObj:(AVObject *)obj{
    _obj = obj;
    if([_obj[@"orderStatus"] isEqualToString:@"1"]) {
        _orderStatus.text = @"待配送";
    }else if([_obj[@"orderStatus"] isEqualToString:@"2"]) {
        _orderStatus.text = @"配送中";
    }else if([_obj[@"orderStatus"] isEqualToString:@"3"]) {
        _orderStatus.text = @"已送达";
    }
    _orderNumber.text = _obj[@"orderNumber"];
}
@end
