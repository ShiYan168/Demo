//
//  AppDelegate.h
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/11.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KTTabBarController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) KTTabBarController *tab;
@end

