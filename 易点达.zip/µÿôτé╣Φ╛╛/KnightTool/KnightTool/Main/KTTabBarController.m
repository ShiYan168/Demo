//
//  KTTabBarController.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/11.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "KTTabBarController.h"
#import "HomeViewController.h"
#import "OrderViewController.h"
#import "SendViewController.h"
#import "FinishViewController.h"

#define BUTTONWIDTH (SCREEN_WIDTH/4)

@implementation KTTabBarController
-(void)viewDidLoad{
    [super viewDidLoad];
    self.tabBar.backgroundImage = [UIImage imageNamed:@"Tab_BackGround"];
    [UITabBar appearance].translucent = NO;
    
    UIImageView  *customView = [[UIImageView alloc] initWithFrame:CGRectMake(0,0, self.tabBar.frame.size.width, self.tabBar.frame.size.height)];
    [customView setImage:[UIImage imageNamed:@"Tab_BackGround"]];
    customView.userInteractionEnabled = YES;
    [self.tabBar addSubview:customView];
    
    [self createViewControllers];
    [self createTabBarItems];
   
}
-(void)createViewControllers
{
    NSArray* classNameArray = @[@"HomeViewController",@"OrderViewController",@"SendViewController",@"FinishViewController"];
    NSArray* titleArray = @[@"小区",@"待配送",@"配送中",@"已送达"];
    NSMutableArray *navArr = [[NSMutableArray alloc]init];
    for (int i=0; i<classNameArray.count; i++) {
        Class class = NSClassFromString(classNameArray[i]);
        UIViewController * vc = [[class alloc]init];
        UINavigationController * nv = [[UINavigationController alloc]initWithRootViewController:vc];
        
            [vc setKTNavTitle:titleArray[i]];
            [vc.navigationController.navigationBar setBackgroundImage:[[UIImage alloc]init] forBarMetrics:UIBarMetricsDefault];
            [vc.navigationController.navigationBar setBarStyle:UIBarStyleDefault];
            [vc.navigationController.navigationBar setShadowImage:[UIImage new]];//导航下边线
            vc.navigationController.navigationBar.barTintColor = KTBaseColor;//导航背景色
            [vc.navigationController.navigationBar setTranslucent:NO];//半透明
            vc.view.backgroundColor = [UIColor whiteColor];
        
        [navArr addObject:nv];
    }
    self.viewControllers = navArr;
}

-(void)createTabBarItems{
   NSArray* imageArray = @[@"icon001Sel",@"icon002Sel",@"icon002Sel",@"icon003Sel",@"icon001",@"icon002",@"icon002",@"icon003"];
    NSArray* titleArray = @[@"小区",@"待配送",@"配送中",@"已送达"];


    _tabbarButtonArray = [NSMutableArray array];
    for (int i=0 ; i<imageArray.count/2; i++){
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(i*BUTTONWIDTH,0,BUTTONWIDTH, self.tabBar.frame.size.height-3);
        [button setTitle:titleArray[i] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [button setTitleColor:KTBaseColor forState:UIControlStateSelected];
        
        button.titleLabel.textAlignment = NSTextAlignmentCenter;
        button.titleLabel.font = [UIFont systemFontOfSize:13];
        [button setImage:[UIImage imageNamed:[imageArray objectAtIndex:i+imageArray.count/2]] forState:UIControlStateNormal];
        [button setImage:[UIImage imageNamed:[imageArray objectAtIndex:i]] forState:UIControlStateSelected];
        [button setTitleEdgeInsets:UIEdgeInsetsMake( (35.0),-button.imageView.frame.size.width, 0.0,0.0)];
        [button setImageEdgeInsets:UIEdgeInsetsMake((-5.0), 5.0,(5.0), -button.titleLabel.bounds.size.width)];

        [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        button.tag = i;
        [_tabbarButtonArray addObject:button];
        if (button.tag == self.selectedIndex) {
            button.selected = YES;
        }
        [self.tabBar addSubview:button];

    }
}

-(void)buttonClick:(UIButton *)sender
{
    [_tabbarButtonArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        UIButton *bt = (UIButton *)obj;
        bt.selected = NO;
    }];
    
    self.selectedIndex = sender.tag;
    sender.selected = YES;
}
@end
