//
//  AppDelegate+KTApp.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/12.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "AppDelegate+KTApp.h"

@implementation AppDelegate (KTApp)
-(void)setThirdLibraryFunction{
    [AVOSCloud setApplicationId:@"AmUd2n0m2pqOQrzDOc96xqAY-gzGzoHsz"clientKey:@"Oq88XlvFFVKNJfO07jy7tcuN"];
    [AVOSCloud setAllLogsEnabled:YES];
    
    IQKeyboardManager *keyboardManager = [IQKeyboardManager sharedManager]; // 获取类库的单例变量
    keyboardManager.enable = YES; // 控制整个功能是否启用
    keyboardManager.shouldResignOnTouchOutside = YES; // 控制点击背景是否收起键盘
    
}
@end
