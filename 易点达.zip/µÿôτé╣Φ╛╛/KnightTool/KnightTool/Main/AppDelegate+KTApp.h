//
//  AppDelegate+KTApp.h
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/12.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "AppDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (KTApp)
-(void)setThirdLibraryFunction;
@end

NS_ASSUME_NONNULL_END
