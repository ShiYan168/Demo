//
//  MBProgressHUD+Show.m
//  FastApp
//
//  Created by tangkunyin on 16/3/7.
//  Copyright © 2016年 www.shuoit.net. All rights reserved.
//


typedef NS_ENUM(NSInteger,MBProgressTipType)
{
    MBProgressTipNone,      //无提示符
    MBProgressTipSuccess,   //正确提示符
    MBProgressTipError      //错误提示符
};
#import "MBProgressHUD+Show.h"
/* 默认网络提示，可在这统一修改 */
static NSString *const kLoadingMessage = @"加载中";

// 获取RGB颜色
#define MBRGBA(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]
#define MBRGB(r,g,b) RGBA(r,g,b,1.0f)
#define MBBlackColor MBRGB(58, 58, 58)
#define MBGrayColor MBRGB(200, 200, 200)

@implementation MBProgressHUD (Show)


//错误提示
+ (void)showError:(NSString *)error
{
   
    [self show:error type:MBProgressTipError completion:nil];
}
//正确提示
+ (void)showSuccess:(NSString *)success
{
    [self show:success type:MBProgressTipSuccess completion:nil];
}
#pragma mark 私有方法：显示信息，然后自动隐藏
+ (void)show:(NSString *)text  type:(MBProgressTipType)type completion:(void (^)(void))completion
{
    if (text.length>0){
        [self hideHUDForView:[UIApplication sharedApplication].keyWindow animated:NO];
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:NO];
        hud.mode = MBProgressHUDModeCustomView;
        switch (type) {
            case MBProgressTipNone:
                hud.mode = MBProgressHUDModeText;
                break;
            case MBProgressTipSuccess:
                hud.customView = [[UIImageView alloc] initWithImage:[UIImage  imageNamed:@"Checkmark-success"]];
                break;
            case MBProgressTipError:
                hud.customView = [[UIImageView alloc] initWithImage:[UIImage  imageNamed:@"Checkmark-error"]];
                break;
        }
        hud.bezelView.color = MBRGB(200, 200, 200);
        hud.detailsLabel.text = text;
        hud.detailsLabel.textColor = MBRGB(58, 58, 58);
        hud.removeFromSuperViewOnHide = YES;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(600 * NSEC_PER_MSEC)), dispatch_get_main_queue(), ^{
            dispatch_async(dispatch_get_main_queue(), ^{
                [UIView animateWithDuration:0.2f animations:^{
                    hud.transform = CGAffineTransformMakeScale(0.8, 0.8);
                } completion:^(BOOL finished) {
                    //800毫秒延迟
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(800 * NSEC_PER_MSEC)), dispatch_get_main_queue(), ^{
                        [hud removeFromSuperview];
                        if (completion) {
                            completion();
                        }
                    });
                }];
            });
        });
    }
}
//加载提示。默认菊花方式
+ (void)startLoadding
{
    [self loaddingWithMessage:nil];
}
+ (void)stopLoadding
{
    [self hideHUDForView:nil];
}
+ (void)loaddingWithMessage:(NSString *)message
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    UIView *loadingView = [[window subviews] lastObject];
    if (![loadingView isKindOfClass:[MBProgressHUD class]]) {
        MBProgressHUD *mbHud = [MBProgressHUD showHUDAddedTo:window animated:NO];
        mbHud.mode = MBProgressHUDModeIndeterminate;
        mbHud.bezelView.color = MBGrayColor;
        mbHud.detailsLabel.text = message;
        mbHud.detailsLabel.textColor = MBBlackColor;
        
//      mbHud.activityIndicatorColor = FSBlackColor; Deprecate: use this below
        [UIActivityIndicatorView appearanceWhenContainedInInstancesOfClasses:@[[MBProgressHUD class]]].color = MBBlackColor;
    }
}

//进度条显示。默认圆圈
+ (void)showProgress:(float)fractionCompleted
{
    [self showProgress:fractionCompleted message:nil];
}

+ (void)showProgress:(float)fractionCompleted message:(NSString *)message
{
    [self showProgress:fractionCompleted message:message mode:MBProgressHUDModeAnnularDeterminate];
}

+ (void)showProgress:(float)fractionCompleted message:(NSString *)message mode:(MBProgressHUDMode)mode
{
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *mbHud = [MBProgressHUD HUDForView:[UIApplication sharedApplication].keyWindow];
        if (!mbHud) {
            mbHud = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
            mbHud.mode = mode;
            mbHud.bezelView.color = MBGrayColor;
            mbHud.label.textColor = MBBlackColor;
        }
        if (fractionCompleted == 1.0f) {
            [mbHud hideAnimated:YES];
        }else{
            mbHud.progress = fractionCompleted;
            mbHud.label.text = message;
        }
    });
}

+ (void)hideHUDForView:(UIView *)view
{
    if (!view) view = [[[UIApplication sharedApplication].keyWindow subviews] lastObject];
    if (![self hideHUDForView:view animated:YES] && [view isKindOfClass:[MBProgressHUD class]]) {
        [NSThread sleepForTimeInterval:0.4];
        [view removeFromSuperview];
    }
}
// 提示后响应某个动作
+ (void)showMessage:(NSString *)message completion:(void (^)(void))completion{
    
}
@end
