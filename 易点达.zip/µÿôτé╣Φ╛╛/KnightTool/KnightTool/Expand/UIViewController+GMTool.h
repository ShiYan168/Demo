//
//  UIViewController+GMTool.h
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/6/1.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (GMTool)

- (void)showToastWithText:(NSString *)toastString;
- (void)showToastWithText:(NSString *)toastString positon:(id)positon;
- (void)showToastWithText:(NSString *)toastString afterDelay:(NSTimeInterval)timeInterval;

//AlertViewControl提示框
- (void)showAlertTitle:(NSString *)title handler:(void (^)(UIAlertAction *action))handler;
- (void)showAlertTitle:(NSString*)title;

//获取当前Controller
- (UIViewController *)containingViewController;
@end

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger,NavigationItemType) {
    NavigationItemTypeleft   = 0,
    NavigationItemTyperight
};

@interface UIViewController (GMTool)
- (void)showToastWithText:(NSString *)toastString;
- (void)showToastWithText:(NSString *)toastString positon:(id)positon;
- (void)showToastWithText:(NSString *)toastString afterDelay:(NSTimeInterval)timeInterval;

//AlertViewControl提示框

- (void)showAlertTitle:(NSString *)title handler:(void (^)(UIAlertAction *action))handler;
-(void)showAlertTitle:(NSString*)title;
-(void)showToastWithMessage:(NSString*)title;

//设置导航标题
- (void)setKTNavTitle:(NSString *)title;
-(void)setNavgationLeftItemBtn;
//设置导航按钮
- (void)setItemWithType:(NavigationItemType)type
                 target:(id)target
                 action:(SEL)action
               btnTitle:(NSString *)btnTitle;
//隐藏键盘
- (void)hideAllKeyBoard;
-(void)logout;
@end

NS_ASSUME_NONNULL_END
