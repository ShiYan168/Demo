//
//  LoginViewController.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/11.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "LoginViewController.h"
#import "AppDelegate.h"
#import "KTTabBarController.h"

@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *phone;
@property (weak, nonatomic) IBOutlet UITextField *passWord;
@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setKTNavTitle:@"登录"];
    [_phone setValue:KTBaseColor forKeyPath:@"_placeholderLabel.textColor"];
    [_passWord setValue:KTBaseColor forKeyPath:@"_placeholderLabel.textColor"];

}
- (IBAction)loginBtnClick:(UIButton *)sender {
    [MBProgressHUD startLoadding];
    __weak typeof(self)wSelf = self;
    AVQuery *query = [AVQuery queryWithClassName:@"KTUser"];
    [query whereKey:@"phone" equalTo:_phone.text];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        [MBProgressHUD stopLoadding];
        if (!error){
            
            if (objects.count>0) {
                AVObject* obj = [objects firstObject];
                if([obj[@"password"] isEqualToString:wSelf.passWord.text]) {
                    [KTSingleData sharedManager].phone = obj[@"phone"];
                    [KTSingleData sharedManager].objectId = obj[@"objectId"];
                    AppDelegate* aud = (AppDelegate*)[UIApplication sharedApplication].delegate;
                    KTTabBarController * tabBarVC = [[KTTabBarController alloc] init];
                    aud.tab = tabBarVC;
                    
                    UIWindow*window= aud.window;//[UIApplication sharedApplication].keyWindow;

                    [UIView transitionWithView:window duration:1.0 options:UIViewAnimationOptionTransitionFlipFromLeft animations:^{
                        //self.view.transform = CGAffineTransformMakeScale(1.5, 1.5);
                        //self.view.alpha=0.8;
                         window.rootViewController=aud.tab;
                    }completion:^(BOOL finished){
                        
                       
                        
//                        [UIView transitionWithView:window duration:1.0 options:UIViewAnimationOptionTransitionFlipFromLeft animations:^
//                         {
//
//                         } completion:^(BOOL finished)
//                         {
//                             window.rootViewController=aud.tab;
//
//                         }];
                        
                    }];
                    
//                    [UIView transitionFromView:self.view
//                     
//                                        toView:tabBarVC.view
//                     
//                                      duration:1.0f
//                     
//                                       options:UIViewAnimationOptionTransitionFlipFromLeft
//                     
//                                    completion:^(BOOL finished) {
//                                        
//                                        
//                                        aud.window.rootViewController = tabBarVC;
//                                        
//                                    }];
                    
                }else{
                    [self showToastWithText:@"账号密码不匹配"];
                }
            }else{
                [self showToastWithText:@"账号不存在"];
            }
            
            
        }else{
            [self showToastWithText:@"非内部会员账号"];
        }
    }];
}
@end
