//
//  CommunityOrderVc.h
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/12.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CommunityOrderVc : UIViewController
@property(nonatomic,copy)NSString* communityId;
@property(nonatomic,copy)NSString* communityName;
@property(nonatomic,copy)NSString* countyId;
@end

NS_ASSUME_NONNULL_END
