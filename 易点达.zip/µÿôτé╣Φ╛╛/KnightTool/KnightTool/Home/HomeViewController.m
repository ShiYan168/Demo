//
//  HomeViewController.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/11.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "HomeViewController.h"
#import "CommunityOrderVc.h"
#import "CountyIdCell.h"
#import "BuildingCell.h"

#define NUMLINE 5
#define NUMInter 5
#define SIZE_ (SCREEN_WIDTH/3*2-5*3)/2
#define TABLE_COLOR RGB(245, 245, 245)

@interface HomeViewController ()<UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>{
    NSInteger _selectIndex;
}
@property(nonatomic,strong)UITableView* leftTableView;
@property(nonatomic,strong)UICollectionViewFlowLayout* layOut;
@property(nonatomic,strong)UICollectionView* rightCollectionView;

@property(nonatomic,strong)NSMutableArray* leftArr;
@property(nonatomic,strong)NSMutableArray* rightArr;
@property (nonatomic,copy) NSString *countyIdStr;

@end

@implementation HomeViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (_countyIdStr.length>0) {
        [self getRightDataWithCountyId:_countyIdStr];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setItemWithType:NavigationItemTyperight target:self action:@selector(rightBtnClick) btnTitle:@"注销"];
    
    _countyIdStr = @"";
    _leftArr = [[NSMutableArray alloc]init];
    _rightArr = [[NSMutableArray alloc]init];
    
    _leftTableView = [[UITableView alloc]init];
    _leftTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _leftTableView.rowHeight = UITableViewAutomaticDimension;
    _leftTableView.estimatedRowHeight = 60;
    _leftTableView.delegate = self;
    _leftTableView.dataSource = self;
    __weak typeof(self)weakSelf = self;
    self.leftTableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf leftRefreshData];
    }];
    _leftTableView.tableFooterView = [UIImageView new];
    [_leftTableView setLayoutMargins:UIEdgeInsetsZero];
    _leftTableView.contentInset = UIEdgeInsetsMake(0, 0,100 , 0);
    [self.view addSubview:_leftTableView];
    [_leftTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.bottom.mas_offset(0);
        make.width.mas_equalTo(SCREEN_WIDTH/3);
    }];
    
    //创建网格布局对象
    _layOut = [[UICollectionViewFlowLayout alloc]init];
    _layOut.scrollDirection = UICollectionViewScrollDirectionVertical;//滑动方向
    _layOut.minimumLineSpacing = NUMLINE;//行间距
    _layOut.minimumInteritemSpacing = NUMInter;//网格间距
    _layOut.sectionInset = UIEdgeInsetsMake(5, 5, 5, 5);//上下左右
    _layOut.itemSize = CGSizeMake(SIZE_, SIZE_);//cell大小
    
    _rightCollectionView = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:_layOut];
    _rightCollectionView.backgroundColor = TABLE_COLOR;
    _rightCollectionView.showsVerticalScrollIndicator = NO;
    _rightCollectionView.delegate = self;
    _rightCollectionView.dataSource = self;
    _rightCollectionView.emptyDataSetSource = self;
    _rightCollectionView.emptyDataSetDelegate = self;
    self.rightCollectionView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf rightRefreshData];
    }];
    
    
    [_rightCollectionView registerNib:[UINib nibWithNibName:@"BuildingCell"bundle:nil] forCellWithReuseIdentifier:@"BuildingCell"];
    
    [self.view addSubview:_rightCollectionView];
    [_rightCollectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.top.bottom.mas_offset(0);
        make.width.mas_equalTo(SCREEN_WIDTH/3*2);
    }];
    
    [self getLeftData];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _leftArr.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CountyIdCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CountyIdCell"];
    
    if (!cell){
        cell= [[[NSBundle  mainBundle]  loadNibNamed:@"CountyIdCell" owner:self options:nil]  lastObject];
        [tableView registerNib:[UINib nibWithNibName:@"CountyIdCell" bundle:nil] forCellReuseIdentifier:@"CountyIdCell"];
    }
    cell.obj = self.leftArr[indexPath.row];
    if (_selectIndex==indexPath.row){
        cell.isSelect = YES;
    }else{
        cell.isSelect = NO;
    }
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    _selectIndex = indexPath.row;
    [self.leftTableView reloadData];
    AVObject* dic = _leftArr[indexPath.row];
    NSString* countyId = [NSString stringWithFormat:@"%@",dic[@"countyId"]];
    _countyIdStr = countyId;
    [self getRightDataWithCountyId:countyId];
    
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return _rightArr.count;
}
//设置网格对象
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //调用自定义Cell
    BuildingCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"BuildingCell" forIndexPath:indexPath];
    cell.rightDic = _rightArr[indexPath.row];
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    AVObject*  dic  = _rightArr[indexPath.row];
    CommunityOrderVc* detailVc = [[CommunityOrderVc alloc]init];
    detailVc.communityId = dic[@"communityId"];
    detailVc.communityName = dic[@"communityName"];
    detailVc.countyId = _countyIdStr;
    detailVc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:detailVc animated:YES];
}
#pragma - mark - 请求数据
-(void)rightRefreshData{
    [self getRightDataWithCountyId:_countyIdStr];
}

-(void)leftRefreshData{
    _selectIndex = 0;
    [self getLeftData];
}

-(void)reloadDataWhenViewWillAppear{
    _selectIndex = 0;
    _countyIdStr = @"";
    [self getLeftData];
}


//左侧小区或楼栋
-(void)getLeftData{
    __weak typeof(self)wself = self;
    AVQuery *query = [AVQuery queryWithClassName:@"County"];
    [query orderByAscending:@"countyId"];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        [wself.leftTableView.mj_header endRefreshing];
        [wself.leftTableView.mj_footer endRefreshing];
        
        if (!error) {
            [wself.leftArr removeAllObjects];
            [wself.leftArr addObjectsFromArray:objects];
            [wself.leftTableView reloadData];
            
            if (objects.count>0) {
                AVObject * dic= wself.leftArr[0];
                NSString* countyId = [NSString stringWithFormat:@"%@",dic[@"countyId"]];
                wself.countyIdStr = [countyId mutableCopy];
                [wself getRightDataWithCountyId:countyId];
            }
            
        }
        
    }];
}
//右侧楼栋
-(void)getRightDataWithCountyId:(NSString*)countyId{
    
    __weak typeof(self)wself = self;
    [MBProgressHUD startLoadding];
    AVQuery *query = [AVQuery queryWithClassName:@"Community"];
    [query orderByDescending:@"orderNums"];
    [query whereKey:@"countyId" equalTo:countyId];
    
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        [MBProgressHUD stopLoadding];
        [wself.rightCollectionView.mj_header endRefreshing];
        [wself.rightCollectionView.mj_footer endRefreshing];
        if (!error) {
            [wself.rightArr removeAllObjects];
            [wself.rightArr addObjectsFromArray:objects];
            [wself.rightCollectionView reloadData];
        }
    }];
}

-(void)rightBtnClick{
    [[UIViewController new] logout];
}
/*
 
 */
@end
