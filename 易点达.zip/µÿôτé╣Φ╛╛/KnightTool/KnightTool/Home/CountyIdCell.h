//
//  CountyIdCell.h
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/13.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CountyIdCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UIImageView *line;
@property (nonatomic,assign)BOOL isSelect;
@property (nonatomic,strong) AVObject *obj;
@end

NS_ASSUME_NONNULL_END
