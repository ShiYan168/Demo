//
//  CountyIdCell.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/13.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "CountyIdCell.h"

@implementation CountyIdCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setObj:(AVObject *)obj{
    _obj = obj;
    _name.text = _obj[@"countyName"];
}
-(void)setIsSelect:(BOOL)isSelect{
    _isSelect = isSelect;
        if (_isSelect){
            _name.textColor = KTBaseColor;
            self.contentView.backgroundColor = KTCommonBgColor;
            _line.hidden  = NO;
        }else{
            _name.textColor = KTlightGrayColor;
            self.contentView.backgroundColor = [UIColor whiteColor];
            _line.hidden = YES;
        }
}
@end
