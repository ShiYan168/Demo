//
//  BuildingCell.m
//  KnightVersion
//
//  Created by ios on 2017/12/27.
//  Copyright © 2017年 ios. All rights reserved.
//

#import "BuildingCell.h"

@implementation BuildingCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
-(void)setRightDic:(AVObject *)rightDic{
    _rightDic = rightDic;
    _build.text = _rightDic[@"communityName"];
    _nums.text= [NSString stringWithFormat:@"%@单",_rightDic[@"orderNums"]];
    NSInteger numsInter = [_rightDic[@"orderNums"] integerValue];
    if (numsInter>0) {
        _build.textColor = KTBaseColor;
        _nums.textColor = KTBaseColor;
    }else{
        _build.textColor = KTlightGrayColor;
        _nums.textColor = KTlightGrayColor;
    }
}
@end
