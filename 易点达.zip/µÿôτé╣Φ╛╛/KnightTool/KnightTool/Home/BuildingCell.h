//
//  BuildingCell.h
//  KnightVersion
//
//  Created by ios on 2017/12/27.
//  Copyright © 2017年 ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BuildingCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *build;
@property (weak, nonatomic) IBOutlet UILabel *nums;
@property (nonatomic,strong) AVObject *rightDic;
@end
