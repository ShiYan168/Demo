//
//  OrderViewController.m
//  KnightTool
//
//  Created by HELLO WORLD on 2019/6/11.
//  Copyright © 2019年 KnightTool. All rights reserved.
//

#import "CommunityOrderVc.h"
#import "OrderDetailController.h"
#import "OrderCell.h"

@interface CommunityOrderVc ()<UITableViewDelegate,UITableViewDataSource,OrderCellDelegate>
@property(nonatomic,strong)UITableView* tabView;
@property(nonatomic,strong)NSMutableArray* mutArr;
@end

@implementation CommunityOrderVc
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
        [self getAllOrderData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _mutArr = [[NSMutableArray alloc] init];
    [self setKTNavTitle:self.communityName];
    [self setNavgationLeftItemBtn];
    
    self.tabView = [[UITableView alloc]init];
    self.tabView.scrollsToTop = YES;
    self.tabView.showsVerticalScrollIndicator = NO;
    self.tabView.rowHeight = UITableViewAutomaticDimension;
    self.tabView.estimatedRowHeight = 100;
    self.tabView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tabView.tableFooterView = [UIImageView new];
    self.tabView.delegate = self;
    self.tabView.dataSource = self;
    __weak typeof(self)weakSelf = self;
    self.tabView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf leftRefreshData];
    }];
    [self.view addSubview:self.tabView];
    [self.tabView mas_makeConstraints:^(MASConstraintMaker *make){
        make.edges.equalTo(self.view).with.insets(UIEdgeInsetsMake(0, 0, 0, 0));
    }];
    //
    //    if(SCREEN_HEIGHT>=812){
    //        [self.tabView mas_makeConstraints:^(MASConstraintMaker *make){
    //            make.edges.equalTo(self.view).with.insets(UIEdgeInsetsMake(-44, 0, 0, 0));
    //        }];
    //    }else{
    //
    //    }
}
-(void)leftRefreshData{
    [self getAllOrderData];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _mutArr.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    OrderCell *cell = [tableView dequeueReusableCellWithIdentifier:@"OrderCell"];
    if (!cell){
        cell= [[[NSBundle  mainBundle]  loadNibNamed:@"OrderCell" owner:self options:nil]  lastObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;//选中状态下颜色为透明色
        [tableView registerNib:[UINib nibWithNibName:@"OrderCell" bundle:nil] forCellReuseIdentifier:@"OrderCell"];
    }
    cell.delegate = self;
    cell.model = _mutArr[indexPath.row];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    AVObject* obj = _mutArr[indexPath.row];
    OrderDetailController* orderVc = [[OrderDetailController alloc] init];
    orderVc.obj = obj;
    [self.navigationController pushViewController:orderVc animated:YES];
}
-(void)reloadViewData{
    [self getAllOrderData];
}
//左侧小区或楼栋
-(void)getAllOrderData{
    __weak typeof(self)wself = self;
    AVQuery *query = [AVQuery queryWithClassName:@"Order"];
    [query orderByDescending:@"updatedAt"];
    [query includeKey:@"address"];
    [query includeKey:@"marki"];
    [query whereKey:@"orderStatus" equalTo:@"1"];
    [query whereKey:@"countyId" equalTo:self.countyId];
    [query whereKey:@"communityId" equalTo:self.communityId];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        [wself.tabView.mj_header endRefreshing];
        [wself.tabView.mj_footer endRefreshing];
        
        if (!error) {
            [wself.mutArr removeAllObjects];
            [wself.mutArr addObjectsFromArray:objects];
            [wself.tabView reloadData];
        }
    }];
}
@end
