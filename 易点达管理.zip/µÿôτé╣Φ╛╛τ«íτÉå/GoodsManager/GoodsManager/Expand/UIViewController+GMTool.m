//
//  UIViewController+GMTool.m
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/6/1.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import "UIViewController+GMTool.h"
#import <objc/runtime.h>



@implementation UIView (GMTool)

//操作成功提示
#pragma mark - Toast

static void *ToastKEY = &ToastKEY;

- (UIView *)toastView {
    return objc_getAssociatedObject(self, ToastKEY);
}

- (void)setToastView:(UIView *)toastView {
    objc_setAssociatedObject(self, ToastKEY, toastView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
- (void)showToastWithText:(NSString *)toastString{
    [self showToastWithText:toastString positon:CSToastPositionCenter];
}
- (void)showToastWithText:(NSString *)toastString positon:(id)positon{
    if (toastString.length > 0) {
        
        if (![self toastView]) {
            [CSToastManager setQueueEnabled:NO];
            [CSToastManager sharedStyle].backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.7];
            [CSToastManager sharedStyle].verticalPadding = 10;
            [CSToastManager sharedStyle].horizontalPadding = 18;
        }
        
        UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
        UIView *toastView = [keyWindow toastViewForMessage:toastString title:nil image:nil style:nil];
        [UIView animateWithDuration:0.3 animations:^{
            [self toastView].alpha = 0 ;
        } completion:^(BOOL finished) {
            [[self toastView] removeFromSuperview];
            [self setToastView:toastView];
        }];
        [keyWindow showToast:toastView duration:0.5 position:positon completion:nil];
    }
}
- (void)showToastWithText:(NSString *)toastString afterDelay:(NSTimeInterval)timeInterval{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(timeInterval * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self showToastWithText:toastString];
    });
}

//AlertViewControl提示框
- (void)showAlertTitle:(NSString *)title handler:(void (^)(UIAlertAction *action))handler{
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"提示"
                                        message:title
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action =
    [UIAlertAction actionWithTitle:@"确定"
                             style:UIAlertActionStyleDefault
                           handler:^(UIAlertAction * _Nonnull action) {
                               if (handler) {
                                   handler(action);
                               }
                           }];
    
    [alert addAction:action];
    UIAlertAction *cancel =
    [UIAlertAction actionWithTitle:@"取消"
                             style:UIAlertActionStyleCancel
                           handler:nil];
    
    [alert addAction:cancel];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alert animated:YES completion:nil];
}
-(void)showAlertTitle:(NSString*)title{
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"提示"
                                        message:title
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action =
    [UIAlertAction actionWithTitle:@"确定"
                             style:UIAlertActionStyleDefault
                           handler:nil];
    
    [alert addAction:action];
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alert animated:YES completion:nil];
}


#pragma - mark - 获取当前页面Controller
-(UIViewController *)currentViewController {
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    UIViewController *vc = keyWindow.rootViewController;
    while (vc.presentedViewController) {
        vc = vc.presentedViewController;
        
        if ([vc isKindOfClass:[UINavigationController class]]) {
            vc = [(UINavigationController *)vc visibleViewController];
        } else if ([vc isKindOfClass:[UITabBarController class]]) {
            vc = [(UITabBarController *)vc selectedViewController];
        }
    }
    return vc;
}
-(UIViewController *)containingViewController{
    UIView * target = self.superview ? self.superview : self;
    return (UIViewController *)[target traverseResponderChainForUIViewController];
}
- (id)traverseResponderChainForUIViewController {
    id nextResponder = [self nextResponder];
    BOOL isViewController = [nextResponder isKindOfClass:[UIViewController class]];
    BOOL isTabBarController = [nextResponder isKindOfClass:[UITabBarController class]];
    if (isViewController && !isTabBarController) {
        return nextResponder;
    } else if(isTabBarController){
        UITabBarController *tabBarController = nextResponder;
        return [tabBarController selectedViewController];
    } else if ([nextResponder isKindOfClass:[UIView class]]) {
        return [nextResponder traverseResponderChainForUIViewController];
    } else {
        return nil;
    }
}

@end


@implementation UIViewController (GMTool)
//操作成功提示
- (void)showToastWithText:(NSString *)toastString{
    [self.view showToastWithText:toastString];
}
- (void)showToastWithText:(NSString *)toastString positon:(id)positon{
    [self.view showToastWithText:toastString positon:positon];
}
- (void)showToastWithText:(NSString *)toastString afterDelay:(NSTimeInterval)timeInterval{
    [self.view showToastWithText:toastString afterDelay:timeInterval];
}

#pragma - mark - AlertViewControl提示框
- (void)showAlertTitle:(NSString *)title handler:(void (^)(UIAlertAction *action))handler{
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"提示"
                                        message:title
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action =
    [UIAlertAction actionWithTitle:@"确定"
                             style:UIAlertActionStyleDefault
                           handler:^(UIAlertAction * _Nonnull action) {
                               if (handler) {
                                   handler(action);
                               }
                           }];
    
    [alert addAction:action];
    UIAlertAction *cancel =
    [UIAlertAction actionWithTitle:@"取消"
                             style:UIAlertActionStyleCancel
                           handler:nil];
    
    [alert addAction:cancel];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)showAlertTitle:(NSString*)title{
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"提示"
                                        message:title
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action =
    [UIAlertAction actionWithTitle:@"确定"
                             style:UIAlertActionStyleDefault
                           handler:nil];
    
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)showToastWithMessage:(NSString*)title{
    [self.view showToastWithText:title];
}

#pragma - mark - Navigation提示框

-(void)setNavgationLeftItemBtn{
    
    UIImage* backImage = [UIImage imageNamed:@"back"];
    UIBarButtonItem* backItem = [[UIBarButtonItem alloc] initWithImage:backImage
                                                                 style:UIBarButtonItemStyleDone
                                                                target:self
                                                                action:@selector(leftBarItemClick)];
    backItem.tintColor = GMBaseColor;
    self.navigationItem.leftBarButtonItem = backItem;
    
}
//设置导航按钮

//文字按钮
- (void)setItemWithType:(NavigationItemType)type
                 target:(id)target
                 action:(SEL)action
               btnTitle:(NSString *)btnTitle{
    UIButton*   btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.titleLabel.font = [UIFont systemFontOfSize:14];
    btn.titleLabel.textAlignment = NSTextAlignmentCenter;
    [btn setTitleColor:GMBaseColor forState:UIControlStateNormal];
    [btn setTitle:btnTitle forState:UIControlStateNormal];
    CGSize size = [btn.titleLabel.text sizeWithAttributes:[NSDictionary dictionaryWithObjectsAndKeys:btn.titleLabel.font,NSFontAttributeName, nil]];
    CGFloat width = size.width+2;
    btn.frame = CGRectMake(0, 0, width, 30);
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    if (type==NavigationItemTypeleft){
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    }else{
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    }
}

-(void)leftBarItemClick{
    //判断跳转
    if (self.presentingViewController) {
        [self dismissViewControllerAnimated:YES completion:nil];
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma - mark - 隐藏键盘
- (void)hideAllKeyBoard
{
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];//隐藏键盘
}

-(UIView *)getView
{
    UIView *view;
    if (self.navigationController.view) {
        view=self.navigationController.view;
    }else{
        view=self.view;
    }
    return view;
}


//#pragma - mark - 页面特殊跳转方式
//-(void)JumpToControlIndex:(NSInteger)index TransitionType:(UISSAnimationType)type whichContol:(NSString *)whichControl{
//    dispatch_async(dispatch_get_main_queue(), ^{
//        [self.navigationController popToRootViewControllerAnimated:NO];
//        AppDelegate* aud = (AppDelegate*)[UIApplication sharedApplication].delegate;
//        if (type==UISSAnimationFromLeft){
//            [aud.tab JumpToControlForIndex:index TransitionType:UISSTransitionFromLeft whichControl:whichControl];
//        }else if(type==UISSAnimationFromRight){
//            [aud.tab JumpToControlForIndex:index TransitionType:UISSTransitionFromRight whichControl:whichControl];
//        }else if(type==UISSAnimationFromBottom){
//            [aud.tab JumpToControlForIndex:index TransitionType:UISSTransitionFromBottom whichControl:whichControl];
//        }else{
//            [aud.tab JumpToControlForIndex:index TransitionType:UISSTransitionFromTop whichControl:whichControl];
//        }
//
//    });
//}
//
////返回指定页面
//-(void)popToControllerWithControlStr:(NSString*)controlStr{
//    NSArray* arr = self.navigationController.viewControllers;
//    for (UIViewController* vc in arr)
//    {
//        if ([vc isKindOfClass:NSClassFromString(controlStr)])
//        {
//            [self.navigationController popToViewController:vc animated:YES];
//            break;
//        }
//    }
//}

@end
