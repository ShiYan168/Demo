//
//  SingleCache.h
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/6/12.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface SingleCache : NSObject
@property(nonatomic,strong)AVObject *address;
@property(nonatomic,assign)NSInteger goodsIdIndex;
+(SingleCache*)sharedManager;
@end
NS_ASSUME_NONNULL_END
