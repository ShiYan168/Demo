//
//  SingleCache.m
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/6/12.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import "SingleCache.h"

@implementation SingleCache
+(SingleCache*)sharedManager{
    static SingleCache* sharedManager = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate,
                  ^{
                      sharedManager = [[self alloc]init];
                  });
    return sharedManager;
}
@end
