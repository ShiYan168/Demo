//
//  AppDelegate.h
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/6/1.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

