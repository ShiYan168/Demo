//
//  PayOrderController.h
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/29.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PayOrderController : UIViewController
@property(nonatomic,copy)NSString* sumsStr;
@property(nonatomic,strong)NSArray* goodsArr;
@end

NS_ASSUME_NONNULL_END
