//
//  PayOrderController.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/29.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "PayOrderController.h"
#import "PayAddressCell.h"
#import "PayGoodsCell.h"
#import "PayKindTCell.h"
#import "AddressController.h"

@interface PayOrderController ()<UITableViewDelegate,UITableViewDataSource>
{
    UILabel* _sums;
}
@property(nonatomic,strong)UITableView* tableView;
@property(nonatomic,strong)NSMutableArray* mutArr;
@property (nonatomic,strong)UIImageView *footView;
@end

@implementation PayOrderController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [_tableView reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    _sums.text = self.sumsStr;
    self.title = @"订单";
    _tableView = [[UITableView alloc]init];
    _tableView.rowHeight = UITableViewAutomaticDimension;
    _tableView.estimatedRowHeight = 100;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableFooterView = [UIImageView new];
    [_tableView setLayoutMargins:UIEdgeInsetsZero];//分割线
    [self.view addSubview:_tableView];
    
    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.mas_offset(0);
        make.bottom.mas_offset(-44);
    }];
    
    [self.view addSubview:self.footView];
    [_footView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.bottom.mas_offset(0);
        make.top.mas_equalTo(_tableView.mas_bottom);
    }];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    switch (section) {
        case 0:
            return 1;
            break;
        case 1:
            return self.goodsArr.count;
            break;
        case 2:
            return 1;
            break;
        case 3:
            return 1;
            break;
        case 4:
            return 1;
            break;
            
        default:
            break;
    }
    return 0;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case 0:
        {
            PayAddressCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PayAddressCell"];
            
            if (!cell){
                cell= [[[NSBundle  mainBundle]  loadNibNamed:@"PayAddressCell" owner:self options:nil]  lastObject];
                [tableView registerNib:[UINib nibWithNibName:@"PayAddressCell" bundle:nil] forCellReuseIdentifier:@"PayAddressCell"];
            }
            cell.addressDic = [SingleCache sharedManager].address;
            return cell;
        }
            break;
        case 1:
        {
            
            PayGoodsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PayGoodsCell"];
            
            if (!cell){
                cell= [[[NSBundle  mainBundle]  loadNibNamed:@"PayGoodsCell" owner:self options:nil]  lastObject];
                [tableView registerNib:[UINib nibWithNibName:@"PayGoodsCell" bundle:nil] forCellReuseIdentifier:@"PayGoodsCell"];
            }
            cell.obj = self.goodsArr[indexPath.row];
            return cell;
        }
            break;
            
        case 2:
        {
            
            PayKindTCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PayKindTCell"];
            
            if (!cell){
                cell= [[[NSBundle  mainBundle]  loadNibNamed:@"PayKindTCell" owner:self options:nil]  lastObject];
                [tableView registerNib:[UINib nibWithNibName:@"PayKindTCell" bundle:nil] forCellReuseIdentifier:@"PayKindTCell"];
            }
            return cell;
        }
            break;
            
        default:
            break;
    }
    return [UITableViewCell new];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.section) {
        case 0:
        {
            AddressController* payVc = [[AddressController alloc] init];
            payVc.isDetail = YES;
            [self.navigationController pushViewController:payVc animated:YES];
            
        }
            break;
            
        default:
            break;
    }
}
-(UIImageView*)footView{
    if (!_footView){
        _footView = [[UIImageView alloc]init];
        _footView.userInteractionEnabled = YES;
        _footView.backgroundColor = [UIColor lightGrayColor];
        UILabel* teml = [[UILabel alloc] init];

        teml.text = @"合计:";
        teml.font = [UIFont systemFontOfSize:17];
        [_footView addSubview:teml];
        [teml mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(_footView);
            make.left.mas_offset(10);
        }];
        
        _sums = [[UILabel alloc] init];
       
        _sums.text = self.sumsStr;
        _sums.font = [UIFont systemFontOfSize:17];
        [_footView addSubview:_sums];
        [_sums mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(_footView);
            make.left.mas_equalTo(teml.mas_right);
        }];
        
        UIButton* payBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [payBtn setTitle:@"提交订单" forState:UIControlStateNormal];
        [payBtn addTarget:self action:@selector(postOrderClick) forControlEvents:UIControlEventTouchUpInside];
        [payBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        payBtn.backgroundColor = TBBaseColor;
        [_footView addSubview:payBtn];
        [payBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.mas_offset(0);
            make.right.mas_offset(0);
            make.width.mas_equalTo(T_WIDTH(120));
        }];
    }
    return _footView;
}
-(void)postOrderClick{
     [self createOrderWithOrderStatus:@"1"];
}
-(void)createOrderWithOrderStatus:(NSString*)orderStatus{
    NSString* addressName = [SingleCache sharedManager].address[@"name"];
    if (!(addressName.length>0)) {
        [self showToastWithText:@"请选择收货地址"];
        return;
    }
    AVObject *todo = [AVObject objectWithClassName:@"Order"];
    
    NSMutableDictionary* addressDic = [[NSMutableDictionary alloc] init];
    [addressDic setObject:[SingleCache sharedManager].address[@"ProvincesStr"] forKey:@"ProvincesStr"];
    [addressDic setObject:[SingleCache sharedManager].address[@"name"] forKey:@"name"];
    [addressDic setObject:[SingleCache sharedManager].address[@"phone"] forKey:@"phone"];
    [addressDic setObject:[SingleCache sharedManager].address[@"detail"] forKey:@"detail"];
    
    [todo setObject:[SingleCache sharedManager].address forKey:@"address"];
    [todo setObject:[SingleCache sharedManager].address[@"communityId"] forKey:@"communityId"];
    [todo setObject:[SingleCache sharedManager].address[@"countyId"] forKey:@"countyId"];
    
    NSMutableArray* tempGoodsArr = [[NSMutableArray alloc]init];
    for (AVObject* obj in self.goodsArr){
        NSMutableDictionary* dic = [[NSMutableDictionary alloc] init];
        [dic setObject:obj[@"goodsIcon"] forKey:@"goodsIcon"];
        [dic setObject:obj[@"goodsName"] forKey:@"goodsName"];
        [dic setObject:obj[@"goodsPrice"] forKey:@"goodsPrice"];
        [dic setObject:obj[@"goodsNums"] forKey:@"goodsNums"];
        [dic setObject:obj[@"goodsId"] forKey:@"goodsId"];
         [dic setObject:obj[@"goodsWeight"] forKey:@"goodsWeight"];
        [tempGoodsArr addObject:dic];
    }
    
    [todo setObject:tempGoodsArr forKey:@"goodsArray"];
    
    CGFloat sunmF = [self.sumsStr floatValue];
    if (sunmF>30) {
        CGFloat orderFreightF = +0.00;
        self.sumsStr = [NSString stringWithFormat:@"%.2f",(orderFreightF+sunmF)];
        [todo setObject:@"0.00" forKey:@"orderFreight"];
        [todo setObject:self.sumsStr forKey:@"orderPrice"];
    }else{
        CGFloat orderFreightF = 3.50;
        self.sumsStr = [NSString stringWithFormat:@"%.2f",(orderFreightF+sunmF)];
        [todo setObject:@"3.50" forKey:@"orderFreight"];
        [todo setObject:self.sumsStr forKey:@"orderPrice"];
    }
    
    
    NSString* onumber = [NSString stringWithFormat:@"%@%@",[[self getCurrentTimeWithFormat:@"yyyyMMddHHmmss"] substringFromIndex:2],[[SingleCache sharedManager].address[@"phone"] substringFromIndex:7]];
    [todo setObject:onumber forKey:@"orderNumber"];
    [todo setObject:orderStatus forKey:@"orderStatus"];
    
    [MBProgressHUD startLoadding];
    [todo saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        [MBProgressHUD stopLoadding];
        if (succeeded){
            [self updateCommunity:[SingleCache sharedManager].address[@"communityId"] CountyId:[SingleCache sharedManager].address[@"countyId"] ];
            
        } else {
            // 失败的话，请检查网络环境以及 SDK 配置是否正确
        }
    }];
}
//加入购物车
-(void)updateCommunity:(NSString*)communityId CountyId:(NSString*)countyId{
    
    AVQuery *query = [AVQuery queryWithClassName:@"Community"];
    [query whereKey:@"communityId" equalTo:communityId];
    [query whereKey:@"countyId" equalTo:countyId];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (!error){
            if (objects.count>0) {
                AVObject* firstObj = [objects firstObject];
                NSInteger nums = [firstObj[@"orderNums"] integerValue];
                [AVQuery doCloudQueryInBackgroundWithCQL:[NSString stringWithFormat:@"update Community set orderNums='%ld' where objectId='%@'",++nums,firstObj[@"objectId"]] callback:^(AVCloudQueryResult *result, NSError *error) {
                    if(!error) {
                        [self showToastWithText:@"订单数量更改成功"];
                    }else{
                        [self showToastWithText:@"订单数量更改失败"];
                    }
                }];
            }
        }else{
            [self showToastWithText:@"订单数量操作失败"];
        }
    }];
}
//获取当地时间
- (NSString *)getCurrentTimeWithFormat:(NSString*)formatStr{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:formatStr];
    NSString *dateTime = [formatter stringFromDate:[NSDate date]];
    return dateTime;
}

@end
