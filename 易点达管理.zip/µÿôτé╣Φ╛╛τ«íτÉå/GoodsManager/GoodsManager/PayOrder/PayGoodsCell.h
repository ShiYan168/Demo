//
//  PayGoodsCell.h
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/29.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PayGoodsCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *goodsIcon;
@property (weak, nonatomic) IBOutlet UILabel *goodsName;
@property (weak, nonatomic) IBOutlet UILabel *goodsBrand;
@property (weak, nonatomic) IBOutlet UILabel *goodsPrice;
@property (weak, nonatomic) IBOutlet UILabel *goodsNums;
@property(nonatomic,strong)AVObject* obj;
@property(nonatomic,strong)NSDictionary* dic;
@end

NS_ASSUME_NONNULL_END
