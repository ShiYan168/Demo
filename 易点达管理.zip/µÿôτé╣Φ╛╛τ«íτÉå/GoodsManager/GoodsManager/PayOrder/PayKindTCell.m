//
//  PayKindTCell.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/29.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "PayKindTCell.h"

@implementation PayKindTCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)topUpClick:(UIButton *)sender {
    
}
@end
