//
//  PayAddressCell.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/29.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "PayAddressCell.h"

@implementation PayAddressCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setAddressDic:(NSDictionary *)addressDic{
    _addressDic = addressDic;
    if (_addressDic!=nil) {
        _name.text = _addressDic[@"name"];
        _phone.text = _addressDic[@"phone"];
        _ProvincesStr.text = [NSString stringWithFormat:@"%@%@",_addressDic[@"ProvincesStr"],_addressDic[@"detail"]];
        _addAddress.hidden = YES;
        _name.hidden = NO;
        _phone.hidden = NO;
        _ProvincesStr.hidden = NO;
        
    }else{
        _addAddress.hidden = NO;
        _name.hidden = YES;
        _phone.hidden = YES;
        _ProvincesStr.hidden = YES;
    }
   
}
-(void)setObj:(AVObject *)obj{
    _obj = obj;
    if (obj!=nil) {
        _name.text = _obj[@"name"];
        _phone.text = _obj[@"phone"];
        _ProvincesStr.text = [NSString stringWithFormat:@"%@%@",_obj[@"ProvincesStr"],_obj[@"detail"]];
        
        _addAddress.hidden = YES;
        _name.hidden = NO;
        _phone.hidden = NO;
        _ProvincesStr.hidden = NO;
        
    }else{
        _addAddress.hidden = NO;
        _name.hidden = YES;
        _phone.hidden = YES;
        _ProvincesStr.hidden = YES;
    }
   
   
}

@end
