//
//  PayGoodsCell.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/29.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "PayGoodsCell.h"

@implementation PayGoodsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}
- (void)setObj:(AVObject *)obj{
    _obj = obj;
    NSString *strimage=_obj[@"goodsIcon"];
    [_goodsIcon sd_setImageWithURL:[NSURL URLWithString:strimage] placeholderImage:[UIImage imageNamed:@"icon_Default_headProtrait"]];
    _goodsName.text = _obj[@"goodsName"];
    _goodsBrand.text = _obj[@"goodsBrand"];;
    _goodsPrice.text = [NSString stringWithFormat:@"¥%@",_obj[@"goodsPrice"]];
    _goodsNums.text = _obj[@"goodsNums"];
}
-(void)setDic:(NSDictionary *)dic{
    _dic = dic;
    NSString *strimage=_dic[@"goodsIcon"];
    [_goodsIcon sd_setImageWithURL:[NSURL URLWithString:strimage] placeholderImage:[UIImage imageNamed:@"icon_Default_headProtrait"]];
    _goodsName.text = _dic[@"goodsName"];
    _goodsBrand.text = _dic[@"goodsBrand"];;
    _goodsPrice.text = [NSString stringWithFormat:@"¥%@",_dic[@"goodsPrice"]];
    _goodsNums.text = _dic[@"goodsNums"];
}
@end
