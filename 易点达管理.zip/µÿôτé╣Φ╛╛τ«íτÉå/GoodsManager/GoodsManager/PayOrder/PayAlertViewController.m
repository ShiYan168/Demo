//
//  PayAlertViewController.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/30.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "PayAlertViewController.h"

@interface PayAlertViewController ()

@end

@implementation PayAlertViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"下单成功";
    [self setNavgationLeftItemBtn];
    // Do any additional setup after loading the view from its nib.
}
-(void)leftBarItemClick{
    //判断跳转
    [self.navigationController popToRootViewControllerAnimated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)sureBtn:(UIButton *)sender {
    //判断跳转
    [self.navigationController popToRootViewControllerAnimated:YES];
}

@end
