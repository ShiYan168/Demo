//
//  ClassLeftViewCell.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/22.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "ClassLeftViewCell.h"

@implementation ClassLeftViewCell

{
    UILabel* commonLabel;
    UIImageView *_lineView;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self= [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = [UIColor lightGrayColor];
        
        _lineView = [[UIImageView alloc]init];
        _lineView.backgroundColor = [UIColor redColor];
        //_lineView.image = [UIImage imageNamed:@"home_commodity_title"];
        [self.contentView addSubview:_lineView];
        [_lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.mas_offset(0);
            make.left.mas_offset(0);
            make.width.mas_equalTo(3);
        }];
        
        commonLabel = [[UILabel alloc] init];
        commonLabel.textColor = [UIColor lightGrayColor];
        commonLabel.font = [UIFont systemFontOfSize:12];
        commonLabel.textAlignment = NSTextAlignmentCenter;
        commonLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:commonLabel];
        [commonLabel mas_makeConstraints:^(MASConstraintMaker *make){
            make.left.equalTo(_lineView.mas_right);
            make.right.mas_offset(0);
            make.centerY.equalTo(_lineView.mas_centerY);
            make.height.mas_equalTo(20);
        }];
    }
    return self;
}
-(void)setTitle:(NSString*)title andSelect:(BOOL)select{
    commonLabel.text = title;
    if (select){
        commonLabel.textColor = GMBaseColor;
        self.contentView.backgroundColor = [UIColor whiteColor];
        _lineView.hidden  = NO;
    }else{
        commonLabel.textColor = GMlightGrayColor;
        self.contentView.backgroundColor = RGB(245, 245, 245);
        _lineView.hidden = YES;
    }
}
-(void)setIsSelect:(BOOL)isSelect{
    _isSelect = isSelect;
    if (_isSelect){
        commonLabel.textColor = [UIColor redColor];
        self.contentView.backgroundColor = [UIColor whiteColor];
        _lineView.hidden  = NO;
    }else{
        commonLabel.textColor = [UIColor lightGrayColor];
        self.contentView.backgroundColor = [UIColor whiteColor] ;
        _lineView.hidden = YES;
    }
}
@end
