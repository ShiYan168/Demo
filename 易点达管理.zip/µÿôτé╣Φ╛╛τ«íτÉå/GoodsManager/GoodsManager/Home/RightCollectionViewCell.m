//
//  RightCollectionViewCell.m
//  HBFrame
//
//  Created by HELLO WORLD on 2018/1/1.
//  Copyright © 2018年 guahibo. All rights reserved.
//
//@property(nonatomic,strong)UIImageView* goodsIcon;
//@property(nonatomic,strong)UILabel* goodsName;
//@property(nonatomic,strong)UILabel* goodsPrice;
//@property(nonatomic,strong)UILabel* saleNums;
//@property(nonatomic,strong)AVObject* obj;

#import "RightCollectionViewCell.h"
#define SIZE (SCREEN_WIDTH-(SCREEN_WIDTH/4+20))/2


@implementation RightCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]){
        self.frame = frame;
        self.backgroundColor = [UIColor whiteColor];
        CGFloat fW = frame.size.width;
        CGFloat fH = frame.size.height;
        _goodsIcon = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, fW,fH-30)];
//        [_goodsIcon setContentMode:UIViewContentModeScaleAspectFill];
//        _goodsIcon.clipsToBounds = YES;
        [self.contentView addSubview:_goodsIcon];
        [_goodsIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_offset(5);
            make.left.mas_offset(15);
            make.right.mas_offset(15);
            make.height.mas_equalTo(fH-50);
        }];
        
        _goodsName = [[UILabel alloc]init];
        _goodsName.textAlignment = NSTextAlignmentLeft;
        _goodsName.font = [UIFont systemFontOfSize:13];
        _goodsName.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_goodsName];
        [_goodsName mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_goodsIcon.mas_bottom);
            make.left.mas_offset(10);
            make.right.mas_offset(-20);
            make.height.mas_equalTo(20);
        }];
        
        _goodsPrice = [[UILabel alloc]init];
        _goodsPrice.textAlignment = NSTextAlignmentLeft;
        _goodsPrice.font = [UIFont systemFontOfSize:13];
        _goodsPrice.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_goodsPrice];
        [_goodsPrice mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_goodsName.mas_bottom);
            make.left.mas_offset(10);
            make.right.mas_offset(-40);
            make.height.mas_equalTo(20);
        }];
        
        UIButton *enterCar = [UIButton buttonWithType:UIButtonTypeCustom];
        [enterCar setBackgroundImage:[UIImage imageNamed:@"goods_list_floatingcart"] forState:UIControlStateNormal];
        [enterCar addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:enterCar];
        [enterCar mas_makeConstraints:^(MASConstraintMaker *make){
            make.size.mas_equalTo(CGSizeMake(T_WIDTH(30), T_WIDTH(30)));
            make.bottom.right.mas_offset(-20);
        }];

    }
    return self;
}

-(void)setObj:(AVObject *)obj{
    _obj = obj;
    [_goodsIcon sd_setImageWithURL:[NSURL URLWithString:obj[@"goodsIcon"]] placeholderImage:[UIImage imageNamed:@"icon_Default_headProtrait"]];
    _goodsName.text = obj[@"goodsName"];
    _goodsPrice.text = [NSString stringWithFormat:@"¥%@",obj[@"goodsPrice"]];
}
//加入购物车
-(void)buttonClick:(UIButton*)btn{
    AVObject* _model = _obj;
        AVQuery *query = [AVQuery queryWithClassName:@"GoodsCar"];
        [query whereKey:@"goodsId" equalTo:_model[@"goodsId"]];
        [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
            if (!error) {
                if (objects.count>0) {
                    AVObject* firstObj = [objects firstObject];
                    NSInteger nums = [firstObj[@"goodsNums"] integerValue];
                    [AVQuery doCloudQueryInBackgroundWithCQL:[NSString stringWithFormat:@"update GoodsCar set goodsNums='%ld' where objectId='%@'",++nums,firstObj[@"objectId"]] callback:^(AVCloudQueryResult *result, NSError *error) {
                        if (!error) {
                             [self showToastWithText:@"成功加入购物车"];
                        }
                    }];
                }else{
                    AVObject *todo = [AVObject objectWithClassName:@"GoodsCar"];
                    [todo setObject:_model[@"goodsId"] forKey:@"goodsId"];
                    [todo setObject:_model[@"goodsIcon"] forKey:@"goodsIcon"];
                    [todo setObject:_model[@"goodsName"] forKey:@"goodsName"];
                    [todo setObject:_model[@"goodsPrice"] forKey:@"goodsPrice"];
                    [todo setObject:_model[@"goodsWeight"] forKey:@"goodsWeight"];
                    [todo setObject:@"1" forKey:@"goodsNums"];
                    
                    [todo saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                        if (succeeded) {
                            [self showToastWithText:@"成功加入购物车"];
                        } else {
                            // 失败的话，请检查网络环境以及 SDK 配置是否正确
                        }
                    }];
                }
            }else{
                 [self showToastWithText:@"操作失败"];
            }
        }];
}
@end
