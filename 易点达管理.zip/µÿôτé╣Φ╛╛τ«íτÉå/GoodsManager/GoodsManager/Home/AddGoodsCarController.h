//
//  AddGoodsCarController.h
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/6/12.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AddGoodsCarController : UIViewController
@property(nonatomic,strong)AVObject* goods;
@end

NS_ASSUME_NONNULL_END
