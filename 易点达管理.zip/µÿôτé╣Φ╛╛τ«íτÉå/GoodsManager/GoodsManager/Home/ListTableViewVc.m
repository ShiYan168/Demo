//
//  ListTableViewVc.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/28.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "ListTableViewVc.h"
#import "ListTableViewCell.h"

@interface ListTableViewVc ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView* tableView;
@property(nonatomic,strong)NSMutableArray* mutArr;
@end

@implementation ListTableViewVc

- (void)viewDidLoad {
    [super viewDidLoad];
     self.title = self.navTitleStr;
    
    _mutArr = [[NSMutableArray alloc] init];
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-44)];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableFooterView = [UIImageView new];
    [_tableView setLayoutMargins:UIEdgeInsetsZero];//分割线
    [self.view addSubview:_tableView];
    
    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        [self.tableView mas_makeConstraints:^(MASConstraintMaker *make){
            make.edges.equalTo(self.view).with.insets(UIEdgeInsetsMake(0, 0, 0, 0));
        }];
    }];
    [self getCarListData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.mutArr.count;
    
}
//高度设为100
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 100;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ListTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"ListTableViewCell"];
    if (cell==nil) {
        cell = [[ListTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ListTableViewCell"];
        cell.selectionStyle =  UITableViewCellSelectionStyleNone;
    }
    AVObject* obj = _mutArr[indexPath.row];
    cell.model = obj[@"goodsDic"];

    return cell;
}
//选中某一行
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
   
}
-(void)getCarListData{
    [MBProgressHUD startLoadding];
    AVQuery *query = [AVQuery queryWithClassName:self.tableNameStr];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        [MBProgressHUD stopLoadding];
        if (!error) {
            [_mutArr removeAllObjects];
            [_mutArr addObjectsFromArray:objects];
            [_tableView reloadData];
        }
    }];
}
@end
