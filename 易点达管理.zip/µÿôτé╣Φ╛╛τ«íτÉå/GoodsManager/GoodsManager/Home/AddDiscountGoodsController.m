//
//  AddGoodsViewController.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/6/1.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "AddDiscountGoodsController.h"
#import "ListTableViewVc.h"

@interface AddDiscountGoodsController ()
{
    AVObject * _obj;
}
@property (weak, nonatomic) IBOutlet UITextField *tableNameTF;
@property (weak, nonatomic) IBOutlet UIImageView *goodsIcon;
@property (weak, nonatomic) IBOutlet UILabel *goodsName;
@property (weak, nonatomic) IBOutlet UILabel *goodsPrice;
@property (weak, nonatomic) IBOutlet UILabel *useScope;
@end

@implementation AddDiscountGoodsController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSUserDefaults* usedF = [NSUserDefaults standardUserDefaults];
    NSString* tableName = [usedF objectForKey:@"tableName"];
    if (tableName.length>0) {
        _tableNameTF.text = tableName;
    }
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"添加折扣商品";
    [self setNavgationLeftItemBtn];
    [self setItemWithType:NavigationItemTyperight target:self action:@selector(rightBtn) btnTitle:@"查看"];
    
    AVQuery *query = [AVQuery queryWithClassName:@"Goods"];
    //[query whereKey:@"productId" containsString:self.productId];模糊查询
    [query whereKey:@"goodsId" equalTo:self.goodsId];
    
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (!error) {
            if (objects.count>0) {
                AVObject* obj = [objects firstObject];
                _obj = obj;
                [_goodsIcon sd_setImageWithURL:[NSURL URLWithString:obj[@"goodsIcon"]] placeholderImage:[UIImage imageNamed:@"icon_Default_headProtrait"]];
                _goodsName.text = obj[@"goodsName"];
                _goodsPrice.text = [NSString stringWithFormat:@"¥%@",obj[@"goodsPrice"]];
                _useScope.text = obj[@"useScope"];
            }else{
                [self showToastWithText:@"商品不存在"];
            }
        }
    }];
}

-(void)rightBtn{
    ListTableViewVc* listVc = [[ListTableViewVc alloc]init];
    listVc.navTitleStr = @"查看";
    NSUserDefaults* usedF = [NSUserDefaults standardUserDefaults];
    NSString* tableName = [usedF objectForKey:@"tableName"];
    listVc.tableNameStr = tableName;
    listVc.headImgName = @"banner4";
    listVc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:listVc animated:YES];
}

- (IBAction)AddGoodsClick:(UIButton *)sender {
    NSUserDefaults* usedF = [NSUserDefaults standardUserDefaults];
    NSString* tableName = [usedF objectForKey:@"tableName"];
    if(!(tableName.length>0)){
        [self showToastWithText:@"请输入表名"];
        return;
    }
    AVQuery *query = [AVQuery queryWithClassName:tableName];
    [query whereKey:@"productId" equalTo:self.goodsId];
    [MBProgressHUD startLoadding];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
         [MBProgressHUD stopLoadding];
        if (!error){
            if (!(objects.count>0)){
                AVObject *todo = [AVObject objectWithClassName:tableName];
                [todo setObject:self.goodsId forKey:@"productId"];
                
                NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
                [dict setObject:_obj[@"goodsIcon"] forKey:@"goodsIcon"];
                [dict setObject:_obj[@"goodsName"] forKey:@"goodsName"];
                [dict setObject:_obj[@"goodsBrand"] forKey:@"goodsBrand"];
                [dict setObject:_obj[@"goodsPrice"] forKey:@"goodsPrice"];
                [dict setObject:_obj[@"productId"] forKey:@"productId"];
                [todo setObject:dict forKey:@"goodsDic"];
                
                [todo saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {

                    if (succeeded) {
                        [self showToastWithText:@"添加成功"];
                    }else{
                        [self showToastWithText:@"添加失败"];
                    }
                    
                }];
            }else{
                [self showToastWithText:@"商品已存在"];
            }
        }else{
            [self showToastWithText:@"请求失败"];
           
            
        }
    }];
}
- (IBAction)saveClick:(UIButton *)sender {
    NSUserDefaults* usedF = [NSUserDefaults standardUserDefaults];
    if (self.tableNameTF.text.length>0) {
        [usedF setObject:self.tableNameTF.text forKey:@"tableName"];
        [usedF synchronize];
    }else{
        [self showToastWithText:@"请输入表名"];
    }
}

@end
