//
//  ListTableViewCell.h
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/28.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ListTableViewCell : UITableViewCell
@property (nonatomic, copy)NSString *product_id;

@property (nonatomic, strong)UIImageView *imgV;

@property (nonatomic, strong)UILabel *nameL;

@property (nonatomic, strong)UILabel *priceL;

@property (nonatomic, strong)UILabel *brandL;

@property (nonatomic, strong)UIButton  *btnL;
@property (nonatomic, strong)NSDictionary  *model;
@end

NS_ASSUME_NONNULL_END
