//
//  ListTableViewCell.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/28.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "ListTableViewCell.h"

@implementation ListTableViewCell

{
    UIButton *enterCar;
}
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //图片
        _imgV = [[UIImageView alloc]init];
        _imgV.frame = CGRectMake(10, 10, 80, 80);
        [self.contentView addSubview:_imgV];
        [_imgV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_offset(10);
            make.bottom.mas_offset(-10);
            make.height.mas_equalTo(60);
            make.width.equalTo(_imgV.mas_height).multipliedBy(1.0f);
        }];
        
        //名称
        _nameL = [[UILabel alloc]init];
        _nameL.frame =CGRectMake(100, 10, SCREEN_WIDTH-100, 20);
        [self.contentView addSubview:_nameL];
        
        //优惠前价格
        _brandL = [[UILabel alloc]init];
        _brandL.frame = CGRectMake(100, 40, 150, 20);
        [self.contentView addSubview:_brandL];
        
        //价格
        _priceL = [[UILabel alloc]init];
        _priceL.frame = CGRectMake(100, 70, 150, 20);
        _priceL.textColor = [UIColor redColor];
        [self.contentView addSubview:_priceL];
        
        enterCar = [UIButton buttonWithType:UIButtonTypeCustom];
        [enterCar setBackgroundImage:[UIImage imageNamed:@"goods_list_floatingcart"] forState:UIControlStateNormal];
        [enterCar addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:enterCar];
        [enterCar mas_makeConstraints:^(MASConstraintMaker *make){
            make.size.mas_equalTo(CGSizeMake(30,30));
            make.right.mas_offset(-10);
            make.centerY.equalTo(self.contentView.mas_centerY);
        }];
    }
    return self;
}
-(void)setModel:(NSDictionary *)model{
    _model = model;
    [_imgV sd_setImageWithURL:[NSURL URLWithString:_model[@"goodsIcon"]] placeholderImage:[UIImage imageNamed:@"icon_Default_headProtrait"]];
    _nameL.text = _model[@"goodsName"];
    _priceL.text = [NSString stringWithFormat:@"¥%@", _model[@"goodsPrice"]];
    _brandL.text = _model[@"goodsBrand"];
}
@end
