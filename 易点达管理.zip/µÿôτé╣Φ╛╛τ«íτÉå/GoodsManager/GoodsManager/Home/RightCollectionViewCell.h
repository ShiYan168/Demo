//
//  RightCollectionViewCell.h
//  HBFrame
//
//  Created by HELLO WORLD on 2018/1/1.
//  Copyright © 2018年 guahibo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface RightCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong)UIImageView* goodsIcon;
@property(nonatomic,strong)UILabel* goodsName;
@property(nonatomic,strong)UILabel* goodsPrice;
@property(nonatomic,strong)UILabel* saleNums;
@property(nonatomic,strong)AVObject* obj;
@end

NS_ASSUME_NONNULL_END
