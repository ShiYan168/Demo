//
//  ClassViewController.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/22.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "ClassViewController.h"
#import "ClassLeftViewCell.h"
#import "RightCollectionViewCell.h"
#import "AddDiscountGoodsController.h"
#import "AddGoodsCarController.h"

#define NUMLINE 0
#define NUMInter 0
#define SIZE_ (SCREEN_WIDTH-(SCREEN_WIDTH/4+20))/2
#define TABLE_COLOR RGB(245, 245, 245)

@interface ClassViewController ()<UITableViewDataSource,UITableViewDelegate,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
{
    NSInteger _selectIndex;
}
@property(nonatomic,strong)UITableView* leftTableView;
@property(nonatomic,strong)NSMutableArray* leftArr;

@property(nonatomic,strong)UICollectionViewFlowLayout* layOut;
@property(nonatomic,strong)UICollectionView* rightCollectionView;
@property(nonatomic,strong)NSMutableArray* rightArr;
@property(nonatomic,copy)NSString* oneIdStr;
@end

@implementation ClassViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if (!(_oneIdStr.length>0)){//如果右侧商品ID不为空就不发送请求
        _selectIndex = 0;
        [self loadLeftData];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _oneIdStr = @"1";
    
    _leftArr = [[NSMutableArray alloc] init];
    _rightArr = [[NSMutableArray alloc] init];

    _leftTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH/4, SCREEN_HEIGHT-64-44)];
    _leftTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _leftTableView.backgroundColor = RGB(248, 248, 248);
    _leftTableView.showsVerticalScrollIndicator = NO;
    _leftTableView.delegate = self;
    _leftTableView.dataSource = self;
    _leftTableView.tableFooterView = [UIImageView new];
    [_leftTableView setLayoutMargins:UIEdgeInsetsZero];//分割线
    _leftTableView.contentInset = UIEdgeInsetsMake(0, 0,TRUEW(45)*2 , 0);
    [self.view addSubview:_leftTableView];
    [_leftTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.bottom.mas_offset(0);
        make.width.mas_equalTo(SCREEN_WIDTH/4+20);
    }];
    
    //创建网格布局对象
    _layOut = [[UICollectionViewFlowLayout alloc]init];
    _layOut.scrollDirection = UICollectionViewScrollDirectionVertical;//滑动方向
    _layOut.minimumLineSpacing = NUMLINE;//行间距
    _layOut.minimumInteritemSpacing = NUMInter;//网格间距
    _layOut.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);//上下左右
    _layOut.itemSize = CGSizeMake(SIZE_, SIZE_+30);//cell大小
    
    _rightCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH/4+20,0,SCREEN_WIDTH-SCREEN_WIDTH/4-20,SCREEN_HEIGHT-108) collectionViewLayout:_layOut];
    _rightCollectionView.backgroundColor = [UIColor whiteColor];
    _rightCollectionView.showsVerticalScrollIndicator = NO;
    _rightCollectionView.delegate = self;
    _rightCollectionView.dataSource = self;
    [_rightCollectionView registerClass:[RightCollectionViewCell class] forCellWithReuseIdentifier:@"RightCollectionViewCell"];
    [self.view addSubview:_rightCollectionView];
    
    [self loadLeftData];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
     return TRUEW(45);
 }
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _leftArr.count>0?_leftArr.count:0;
}
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        
        [cell setSeparatorInset:UIEdgeInsetsZero];
        
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        
        [cell setLayoutMargins:UIEdgeInsetsZero];
        
    }
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ClassLeftViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"ClassLeftViewCell"];
    if(cell==nil) {
        cell = [[ClassLeftViewCell alloc ]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ClassLeftViewCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    if (_selectIndex==indexPath.row){
        [cell setTitle:_leftArr[indexPath.row][@"oneName"] andSelect:YES];
    }else{
        [cell setTitle:_leftArr[indexPath.row][@"oneName"] andSelect:NO];
    }
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    _selectIndex = indexPath.row;
    [self.leftTableView reloadData];
    AVObject * obj = (AVObject*)_leftArr[indexPath.row];
   [self getRightDataWithBrand:obj[@"oneId"]];
}

//设置网格个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return _rightArr.count;
}

//设置网格对象
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //调用自定义Cell
    RightCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"RightCollectionViewCell" forIndexPath:indexPath];
    AVObject* obj = (AVObject*)_rightArr[indexPath.row];
    cell.obj = obj;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
        AddGoodsCarController* goodsCarVc = [[AddGoodsCarController alloc]initWithNibName:@"AddGoodsCarController" bundle:nil];
        goodsCarVc.goods =(AVObject*)_rightArr[indexPath.row];
        goodsCarVc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:goodsCarVc animated:YES];
}
-(void)loadLeftData{
    AVQuery *query = [AVQuery queryWithClassName:@"OneClass"];
    __weak typeof(self)wself = self;
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (!error) {
            [wself.leftArr removeAllObjects];
            [wself.leftArr addObjectsFromArray:objects];
            AVObject* obj = (AVObject*)wself.leftArr[0];
            wself.oneIdStr = obj[@"oneId"];
            [wself getRightDataWithBrand:wself.oneIdStr];
        }
        [wself.leftTableView reloadData];
    }];
}
-(void)getRightDataWithBrand:(NSString*)idString{
    [MBProgressHUD startLoadding];
    __weak typeof(self)wself = self;

    AVQuery *query = [AVQuery queryWithClassName:@"Goods"];
         [query whereKey:@"oneId" equalTo:idString];
         [query orderByAscending:@"productId"];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
         [MBProgressHUD stopLoadding];
        if (!error) {
            [wself.rightArr removeAllObjects];
            [wself.rightArr addObjectsFromArray:objects];
            [wself.rightCollectionView reloadData];
        }else{
            [self showToastWithText:@"服务器连接失败!"];
        }
    }];
}

@end
