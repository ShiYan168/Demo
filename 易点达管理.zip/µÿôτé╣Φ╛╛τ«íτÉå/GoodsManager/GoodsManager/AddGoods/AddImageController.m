//
//  AddImageController.m
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/6/4.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import "AddImageController.h"
#import "ArtImageSelectView.h"

@interface AddImageController (){
    UILabel* _imgLabel;
}
@property (nonatomic,strong) ArtImageSelectView*  imgSel;
@property (nonatomic,strong) NSMutableArray*  imageUrlArray;
@end

@implementation AddImageController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"添加商品";
    _imageUrlArray = [[NSMutableArray alloc] init];
    self.view.backgroundColor = [UIColor whiteColor];
    
    _imgSel = [ArtImageSelectView new];
    _imgSel.maxNumberOfImage = 6;
    _imgSel.allowEdit = YES;
    __weak typeof(self)wself = self;
    _imgSel.baseVC = wself;
    [self.view addSubview:_imgSel];
    
    [_imgSel mas_makeConstraints:^(MASConstraintMaker* make) {
        make.top.mas_equalTo(100);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.height.mas_equalTo(300);
    }];
    

    UILabel* label = [[UILabel alloc] init];
    label.numberOfLines = 0;
    _imgLabel = label;
    [self.view addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker* make) {
        make.top.mas_equalTo(wself.imgSel.mas_bottom);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.height.mas_equalTo(200);
    }];
    
    
    UIButton* btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn addTarget:self action:@selector(startPostImage) forControlEvents:UIControlEventTouchUpInside];
    [btn setTitle:@"开始上传" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn setBackgroundColor:GMBaseColor];
    [self.view addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker* make) {
        make.top.mas_equalTo(label.mas_bottom);
        make.left.mas_equalTo(0);
        make.right.mas_equalTo(0);
        make.height.mas_equalTo(40);
    }];
    
}
-(void)startPostImage{
    
    if (_imgSel.listImages.count>0){
        [self setUpTestWithImageArr:[_imgSel.listImages mutableCopy] withIndex:0];
    }
}
//上传图像到云服务器
-(void)setUpTestWithImageArr:(NSArray *)imageArr withIndex:(int)index
{
    if (index==imageArr.count) {
        [self showToastWithText:@"上传完成"];
    
        NSString* productImage = [self.imageUrlArray componentsJoinedByString:@","];
        _imgLabel.text = productImage;
        NSLog(@"productImage==%@",productImage);
        [self.manager sendGoodsIcon:self.imageUrlArray[0] productImage:productImage];
    }else{
        
    __weak typeof(self)wself = self;
    NSString* imageNameStr = [NSString stringWithFormat:@"%@%d.png",[[self getCurrentTimeWithFormat:@"yyyyMMddHHmmss"] substringFromIndex:2],index];
    UIImage* img = _imgSel.listImages[index];
    NSData* data = UIImagePNGRepresentation(img);
    AVFile *file = [AVFile fileWithData:data name:imageNameStr];
        index++;
        [MBProgressHUD startLoadding];
    [file uploadWithCompletionHandler:^(BOOL succeeded, NSError * _Nullable error) {
        [MBProgressHUD stopLoadding];
        if (succeeded) {
            NSLog(@"%d==file.url==%@",index,file.url);
            [wself.imageUrlArray addObject:file.url];
            [wself setUpTestWithImageArr:imageArr withIndex:(index)];
        }else{
            [self showToastWithText:[NSString stringWithFormat:@"第%d张上传失败",index]];
        }
    }];
   }
}
//获取当地时间
- (NSString *)getCurrentTimeWithFormat:(NSString*)formatStr{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:formatStr];
    NSString *dateTime = [formatter stringFromDate:[NSDate date]];
    return dateTime;
}
@end
