//
//  AddImageController.h
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/6/4.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol AddImageControllerDelegate
- (void)sendGoodsIcon:(NSString*)goodsIcon productImage:(NSString*)productiImage;//数量+1
@end

@interface AddImageController : UIViewController
@property (nonatomic,weak)id<AddImageControllerDelegate>manager;
@end

NS_ASSUME_NONNULL_END
