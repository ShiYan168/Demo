//
//  ArtImageSelectView.h
//  Test
//
//  Created by ios on 2017/12/17.
//  Copyright © 2017年 ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ArtImageSelectView : UIImageView
///图片列表
@property (nonatomic, strong) NSMutableArray<UIImage*>* listImages;
///最多可选择的图片数
@property (nonatomic, readwrite) int maxNumberOfImage;
///是否允许编辑
@property (nonatomic, readwrite) BOOL allowEdit;
@property (nonatomic, readwrite) BOOL allowScroll;

@property (nonatomic, copy) void (^selectAddBtnCilck)(UIImage*);
@property (nonatomic, copy) void (^selectDelBtnCilck)(NSInteger);
@property (nonatomic, copy) void (^reloadHeight)(CGFloat);

@property (nonatomic, weak) UIViewController* baseVC;
@end
