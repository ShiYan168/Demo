//
//  PostGoodsController.m
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/6/3.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import "AddGoodsController.h"
#import "AddImageController.h"

@interface AddGoodsController ()<AddImageControllerDelegate>

@property (nonatomic,copy) NSString*  goodsIconStr;
@property (nonatomic,copy) NSString*  goodsImagesStr;
@property (weak, nonatomic) IBOutlet UIImageView *goodsIconView;
@property (weak, nonatomic) IBOutlet UILabel *goodsIcon;
@property (weak, nonatomic) IBOutlet UILabel *goodsImages;
@property (weak, nonatomic) IBOutlet UITextField *goodsName;
@property (weak, nonatomic) IBOutlet UITextField *goodsPrice;
@property (weak, nonatomic) IBOutlet UITextField *goodsId;
@property (weak, nonatomic) IBOutlet UITextField *goodsWeight;
@property (weak, nonatomic) IBOutlet UITextField *oneId;

@end

@implementation AddGoodsController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if ([SingleCache sharedManager].goodsIdIndex) {
        self.goodsId.text = [NSString stringWithFormat:@"%ld",[SingleCache sharedManager].goodsIdIndex+1];
    }
}
-(void)viewDidLoad{
    [super viewDidLoad];
}

- (IBAction)addProduct:(UIButton *)sender {
    AddImageController* addImgVc = [[AddImageController alloc] init];
    addImgVc.manager = self;
    [self.navigationController pushViewController:addImgVc animated:YES];
}
- (IBAction)postButton:(UIButton *)sender {
    if (!(_goodsIconStr.length>0)){
        [self showToastWithText:@"商品封面"];
        return;
    }
    
    if (!(_goodsName.text.length>0)) {
        [self showToastWithText:@"_goodsName"];
        return;
    }
   
    if (!(_goodsPrice.text.length>0)) {
        [self showToastWithText:@"goodsPrice"];
        return;
    }
    if (!(_oneId.text.length>0)) {
        [self showToastWithText:@"oneId"];
        return;
    }
    if (!(_goodsId.text.length>0)) {
        [self showToastWithText:@"goodsId"];
        return;
    }
    if (!(_goodsWeight.text.length>0)) {
        [self showToastWithText:@"goodsWeight"];
        return;
    }

   
    AVObject *todo = [AVObject objectWithClassName:@"Goods"];
    [todo setObject:_goodsIconStr forKey:@"goodsIcon"];
    [todo setObject:_goodsName.text forKey:@"goodsName"];
    [todo setObject:_goodsPrice.text forKey:@"goodsPrice"];
    [todo setObject:_oneId.text forKey:@"oneId"];
     [todo setObject:_goodsId.text forKey:@"goodsId"];
    [todo setObject:_goodsWeight.text forKey:@"goodsWeight"];
    
    [MBProgressHUD startLoadding];
    [todo saveInBackgroundWithBlock:^(BOOL succeeded, NSError * _Nullable error) {
        [MBProgressHUD stopLoadding];
        if (succeeded) {
            [self showToastWithText:@"上传成功"];
            [SingleCache sharedManager].goodsIdIndex = [_goodsId.text integerValue];
        }else{
            [self showToastWithText:@"上传失败"];
        }
    }];
    
}
-(void)sendGoodsIcon:(NSString *)goodsIcon productImage:(NSString *)productiImage{
    [self.goodsIconView sd_setImageWithURL:[NSURL URLWithString:goodsIcon] placeholderImage:[UIImage imageNamed:@"icon_Default_headProtrait"]];

    self.goodsIconStr = goodsIcon;
    self.goodsIcon.text = goodsIcon;
    self.goodsImagesStr = productiImage;
    self.goodsImages.text = productiImage;
}
@end
