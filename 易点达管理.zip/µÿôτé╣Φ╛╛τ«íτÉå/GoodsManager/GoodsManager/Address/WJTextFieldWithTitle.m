//
//  STextFieldWithTitle.h
//  ArtistProject
//
//  Created by HELLO WORLD on 2017/4/19.
//  Copyright © 2017年 HELLO WORLD. All rights reserved.

#import "WJTextFieldWithTitle.h"

@interface WJTextFieldWithTitle (){
    UILabel *lblTitle;
    UILabel *lblsubmit;
    UIImageView *imgArrow;
}

@end

@implementation WJTextFieldWithTitle

-(id)init{
    if (self=[super init]) {
        [self customInit];
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
        [self customInit];
    }
    return self;
}

- (void) customInit
{
    self.backgroundColor=[UIColor whiteColor];
//    self.layer.cornerRadius = 5;
//    self.layer.borderColor  = [[UIColor grayColor] CGColor];
//    self.layer.borderWidth = 1;
//    self.layer.masksToBounds = YES;
    lblTitle=[[UILabel alloc]init];
   
    [self addSubview:lblTitle];
    [lblTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.left.equalTo(self).offset(10);
        make.width.mas_equalTo(80);
        make.height.mas_equalTo(18);
    }];
    
    lblsubmit=[[UILabel alloc]init];
    lblsubmit.textAlignment=NSTextAlignmentRight;
    lblsubmit.numberOfLines = 0;
    [self addSubview:lblsubmit];
    [lblsubmit mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.left.equalTo(lblTitle.mas_right).offset(10);
        make.right.equalTo(self).offset(-25);
        make.height.greaterThanOrEqualTo(@18);
    }];
    
    //右箭头
    imgArrow=[[UIImageView alloc]init];
    imgArrow.backgroundColor = [UIColor clearColor];
    imgArrow.image = [UIImage imageNamed:@"right_img"];
    [self addSubview:imgArrow];
    [imgArrow mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.right.equalTo(self).offset(-5);
        make.width.mas_equalTo(10);
        make.height.mas_equalTo(15);
    }];
    
    self.userInteractionEnabled=YES;
    UITapGestureRecognizer *tapClick=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap_Click)];
    [self addGestureRecognizer:tapClick];
}

-(void)setHeadLineWidth:(CGFloat)headLineWidth{
    _headLineWidth=headLineWidth;

}

-(void)setTitle:(NSString *)title{
    _title=title;
    lblTitle.text=title;
    
    CGSize size = [lblTitle.text sizeWithAttributes:[NSDictionary dictionaryWithObjectsAndKeys:lblTitle.font,NSFontAttributeName, nil]];
   CGFloat width =  size.width+2;
    [lblTitle mas_updateConstraints:^(MASConstraintMaker *make){
        make.width.mas_equalTo(width);
    }];
}

-(void)tap_Click{
    
    if (self.didTapBlock) {
        self.didTapBlock();
    }
}

-(void)setSubmit:(NSString *)submit{
    _submit=submit;
    lblsubmit.text=submit;
}

-(void)setIsHideArrow:(BOOL)isHideArrow{
    _isHideArrow=isHideArrow;
    imgArrow.hidden=YES;
    self.userInteractionEnabled=NO;
}

-(void)setSubmitAligent:(NSTextAlignment)submitAligent{
    _submitAligent=submitAligent;
    lblsubmit.textAlignment=submitAligent;
    [lblsubmit mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(lblTitle.mas_right).offset(15);
    }];
}

-(void)setSubmitColor:(UIColor *)submitColor{
    _submitColor=submitColor;
    lblsubmit.textColor=submitColor;
}

-(void)setIsMutable:(BOOL)isMutable{
    if (isMutable) {
        lblsubmit.numberOfLines=0;
    }
}

-(void)setIsMutableChage:(BOOL)isMutableChage{
    if (isMutableChage) {
        lblsubmit.numberOfLines=0;
        [lblsubmit mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self).offset(15);
            make.width.mas_equalTo(SCREEN_WIDTH-80);
            make.right.equalTo(self).offset(-25);
        }];
        [self mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(lblsubmit).offset(15);
        }];
    }
}

-(void)setIsMutableChageShow:(BOOL)isMutableChageShow{
    _isMutableChageShow=isMutableChageShow;
    if (isMutableChageShow) {
        [lblTitle mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self).offset(15);
            make.left.equalTo(self).offset(15);
            make.width.mas_equalTo(self.HeightMutableChageShow);
        }];
        
        lblsubmit.numberOfLines=0;
        [lblsubmit mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self).offset(15);
            make.left.equalTo(lblTitle.mas_right);
            make.right.equalTo(self).offset(-25);
        }];
        
        [self mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(lblsubmit).offset(15);
        }];
        
    }
}

-(void)setSubmitFont:(UIFont *)submitFont{
    lblsubmit.font=submitFont;
}

-(void)setTitleColor:(UIColor *)titleColor{
    lblTitle.textColor=titleColor;
}
-(void)setImgStr:(NSString *)imgStr{
    _imgStr = imgStr;
     imgArrow.image = [UIImage imageNamed:imgStr];
}
@end
