//
//  TBFieldWithTitle.m
//  TomatoBox
//
//  Created by HELLO WORLD on 2017/11/26.
//  Copyright © 2017年 ios. All rights reserved.
//

#import "TBFieldWithTitle.h"

@implementation TBFieldWithTitle
{
    UILabel *leftTitle;
    UIImageView *lineView;
}
-(id)init{
    if (self=[super init]) {
        [self customInit];
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
        [self customInit];
    }
    return self;
}
-(void)customInit{
    self.backgroundColor = [UIColor whiteColor];
    self.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapClick=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap_Click)];
    [self addGestureRecognizer:tapClick];
    
    leftTitle=[[UILabel alloc]init];
    [self addSubview:leftTitle];
    [leftTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.size.mas_equalTo(CGSizeMake(80, 20));
        make.left.equalTo(self).offset(10);
    }];
    
    _editField=[[UITextField alloc]init];
    _editField.clearButtonMode = UITextFieldViewModeAlways;
  
    [self addSubview:_editField];
    [_editField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.height.mas_equalTo(20);
        make.left.equalTo(leftTitle.mas_right).offset(10);
        make.right.mas_offset(-10);
    }];
    
    lineView=[[UIImageView alloc]init];
    lineView.backgroundColor = RGB(150, 150, 150);
    [self addSubview:lineView];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self);
        make.height.mas_equalTo(0.5);
        make.left.right.mas_offset(0);
    }];
}
-(void)setKeyTitleColor:(UIColor *)keyTitleColor{
    _keyTitleColor = keyTitleColor;
    leftTitle.textColor = _keyTitleColor;
}
-(void)tap_Click{
    [_editField becomeFirstResponder];
}
-(void)setKeyTitle:(NSString *)keyTitle{
    _keyTitle = keyTitle;
    leftTitle.text = _keyTitle;
}
@end
