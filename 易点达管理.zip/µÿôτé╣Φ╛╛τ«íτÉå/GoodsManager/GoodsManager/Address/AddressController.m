//
//  AddressController.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/28.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "AddressController.h"
#import "AddressCell.h"
#import "NewAddressController.h"

@interface AddressController ()<UITableViewDelegate,UITableViewDataSource,AddressCellDelegate>
@property(nonatomic,strong)UITableView* tableView;
@property(nonatomic,strong)NSMutableArray* mutArr;
@end

@implementation AddressController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self getCarListData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"地址";
    _mutArr = [[NSMutableArray alloc] init];
    [self setNavgationLeftItemBtn];
    [self setItemWithType:NavigationItemTyperight target:self action:@selector(rightBarItem_Click) btnTitle:@"新增"];
    
    self.view.backgroundColor = TBViewBack_COLOR;
    
    _tableView = [[UITableView alloc]init];
    _tableView.rowHeight = UITableViewAutomaticDimension;
    _tableView.estimatedRowHeight = 100;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.backgroundColor = FSCommonBgColor;
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableFooterView = [UIImageView new];
    [_tableView setLayoutMargins:UIEdgeInsetsZero];//分割线
    [self.view addSubview:_tableView];
    
    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.mas_offset(0);
        make.bottom.mas_offset(-44);
    }];
}
-(void)getCarListData{
    [MBProgressHUD startLoadding];
    AVQuery *query = [AVQuery queryWithClassName:@"Address"];
    [query orderByDescending:@"updatedAt"];
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (!error) {
            [_mutArr removeAllObjects];
            [_mutArr addObjectsFromArray:objects];
            [_tableView reloadData];
        }
        [MBProgressHUD stopLoadding];
    }];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
     return _mutArr.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIImageView* headView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 10)];
    headView.backgroundColor = TBViewBack_COLOR;
    return headView;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    AddressCell *cell = [tableView dequeueReusableCellWithIdentifier:@"AddressCell"];
    
    if (!cell){
        cell= [[[NSBundle  mainBundle]  loadNibNamed:@"AddressCell" owner:self options:nil]  lastObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;//选中状态下颜色为透明色
        [tableView registerNib:[UINib nibWithNibName:@"AddressCell" bundle:nil] forCellReuseIdentifier:@"AddressCell"];
    }
    __weak typeof(self)wself = self;
    cell.manager = wself;
    cell.obj = (AVObject*)_mutArr[indexPath.section];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.isDetail) {
        [SingleCache sharedManager].address = (AVObject*)_mutArr[indexPath.section];
        [self.navigationController popViewControllerAnimated:YES];
    }else{
        NewAddressController* newAddress = [[NewAddressController alloc] initWithNibName:@"NewAddressController" bundle:nil];
        [self.navigationController pushViewController:newAddress animated:YES];
    }
    
}
- (void)editAddress:(AVObject*)obj{
//    NewAddressController* newAddress = [[NewAddressController alloc] initWithNibName:@"NewAddressController" bundle:nil];
//    newAddress.obj = obj;
//    [self.navigationController pushViewController:newAddress animated:YES];
}
- (void)deleteAddress:(AVObject*)obj{
    if ([obj[@"isDefault"] isEqualToString:@"1"]) {
        [self showToastWithText:@"默认地址不能删除"];
        return;
    }
    [MBProgressHUD startLoadding];
    [AVQuery doCloudQueryInBackgroundWithCQL:[NSString stringWithFormat:@"delete from Address where objectId='%@'",obj[@"objectId"]] callback:^(AVCloudQueryResult *result, NSError *error){
          [MBProgressHUD stopLoadding];
        if (!error) {
            [self getCarListData];
        }else{
            [MBProgressHUD showError:@"操作失败"];
        }
    }];
}
-(void)rightBarItem_Click{
    NewAddressController* newAddress = [[NewAddressController alloc] initWithNibName:@"NewAddressController" bundle:nil];
    [self.navigationController pushViewController:newAddress animated:YES];
}
@end
