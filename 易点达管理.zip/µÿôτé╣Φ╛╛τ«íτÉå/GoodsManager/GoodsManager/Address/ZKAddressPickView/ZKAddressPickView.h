//
//  ZKAddressPickView.h
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/9/8.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class ZKAddressToolBar,ZKAddressPicker;

typedef void(^ZKAddressPickViewPickBlock)(NSDictionary *dic);

@interface ZKAddressPickView : UIView

/// Default is 0.3.
@property (nonatomic,assign) CGFloat  grayViewAlpha;
/// Default is 'NO'.
@property (nonatomic,assign) BOOL  hideWhenTapGrayView;
/// Default is 3, two value to set: 2 or 3,
@property (nonatomic,assign) NSInteger  columns;
///
@property (nonatomic,copy)ZKAddressPickViewPickBlock pickBlock;
///
@property (nonatomic,strong,readonly) ZKAddressToolBar *toolBar;
///
@property (nonatomic,strong,readonly) ZKAddressPicker *picker;

- (void)showInView:(UIView *)view;
- (void)hide;

@end

NS_ASSUME_NONNULL_END
