//
//  TBFieldWithTitle.h
//  TomatoBox
//
//  Created by HELLO WORLD on 2017/11/26.
//  Copyright © 2017年 ios. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface TBFieldWithTitle : UIImageView
@property (strong, nonatomic)UIColor *keyTitleColor;
@property (strong, nonatomic)NSString *keyTitle;
@property (strong, nonatomic)UITextField *editField;;
@end
