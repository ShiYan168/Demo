//
//  AddressCell.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/28.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "AddressCell.h"

@implementation AddressCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setObj:(AVObject *)obj{
    _obj = obj;
    _name.text = _obj[@"name"];
    _phone.text = _obj[@"phone"];
    _address.text = [NSString stringWithFormat:@"%@%@",_obj[@"ProvincesStr"],_obj[@"detail"]];
    if ([_obj[@"isDefault"] isEqualToString:@"1"]) {
        _isDefault.hidden = NO;
    }else{
        _isDefault.hidden = YES;
    }
}
- (IBAction)editBtnClick:(UIButton *)sender {
    [self.manager editAddress:_obj];
}
- (IBAction)deleteBtnClick:(UIButton *)sender {
   // [self.manager deleteAddress:_obj];
}

@end
