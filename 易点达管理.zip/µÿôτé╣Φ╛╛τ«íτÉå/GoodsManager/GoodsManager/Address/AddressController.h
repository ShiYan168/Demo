//
//  AddressController.h
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/28.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AddressController : UIViewController
@property(nonatomic,assign)BOOL isDetail;
@end

NS_ASSUME_NONNULL_END
