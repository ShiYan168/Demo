//
//  AddressCell.h
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/28.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol AddressCellDelegate
- (void)editAddress:(AVObject*)obj;
- (void)deleteAddress:(AVObject*)obj;
@end

@interface AddressCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *phone;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UILabel *isDefault;
@property (nonatomic,weak)id<AddressCellDelegate>manager;
@property(nonatomic,strong)AVObject* obj;
@end

NS_ASSUME_NONNULL_END
