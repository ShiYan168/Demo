//
//  NewAddressController.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/29.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "NewAddressController.h"
#import "TBFieldWithTitle.h"
#import "WJTextFieldWithTitle.h"
#import "DXLAddressPickView.h"
#import "ZKAddressPickView.h"


@interface NewAddressController ()<UITextFieldDelegate>
{
    BOOL  _isDefault;
    UIImageView*  imgArrow;
    UILabel* commonLabel;
    UILabel* detailLabel;
    
}
@property (nonatomic,strong)TBFieldWithTitle* name;
@property (nonatomic,strong)TBFieldWithTitle* phone;
@property (nonatomic,strong)WJTextFieldWithTitle* ProvincesStr;
@property (nonatomic,strong)UITextField* detailView;
//@property (nonatomic,strong)DXLAddressPickView *pickerView;
@property (nonatomic,strong)ZKAddressPickView *pickView;

@property (nonatomic,copy)NSString* countyId;
@property (nonatomic,copy)NSString* communityId;


@end

@implementation NewAddressController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"新增地址";
    [self setNavgationLeftItemBtn];
    [self setItemWithType:NavigationItemTyperight target:self action:@selector(rightBarItem_Click) btnTitle:@"保存"];
    
    _name = [[TBFieldWithTitle alloc]init];
    _name.editField.delegate = self;
    _name.keyTitle  = @"收货人";
    [self.view addSubview:_name];
    [_name mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.mas_offset(64);
        make.left.right.mas_offset(0);
        make.height.mas_equalTo(50);
    }];
    
    _phone = [[TBFieldWithTitle alloc]init];
    _phone.editField.keyboardType = UIKeyboardTypePhonePad;
    _phone.editField.delegate = self;
    _phone.keyTitle  = @"联系电话";
    
    [self.view addSubview:_phone];
    [_phone mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(_name.mas_bottom);
        make.left.right.mas_offset(0);
        make.height.mas_equalTo(50);
    }];
    
    //__weak typeof(self)weakSelf = self;
    // _pickerView = [[DXLAddressPickView alloc] init];
    _pickView = [[ZKAddressPickView alloc] init];
    _pickView.hideWhenTapGrayView = YES;
    //_pickView.columns = 2;    // 省市二级选择
    _pickView.columns = 3;  // 省市区三级选择
    _pickView.pickBlock = ^(NSDictionary *dic) {
        NSLog(@"所选地址:%@",dic);
    };
    [_pickView showInView:self.view];
    
    _ProvincesStr = [[WJTextFieldWithTitle alloc]init];
    _ProvincesStr.title  = @"所在地区";
    _ProvincesStr.didTapBlock = ^{
        
        //        [weakSelf.pickerView show];
        //        weakSelf.pickerView.determineBtnBlock = ^(NSString *shengId, NSString *shiId, NSString *xianId, NSString *shengName, NSString *shiName, NSString *xianName, NSString *postCode) {
        //            weakSelf.ProvincesStr.submit = [NSString stringWithFormat:@"%@ %@ %@",shengName,shiName,xianName];
        //            weakSelf.countyId = shengId;
        //            weakSelf.communityId = shiId;
        //        };
        [_pickView showInView:self.view];
        
    };
    [self.view addSubview:_ProvincesStr];
    [_ProvincesStr mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(_phone.mas_bottom);
        make.left.right.mas_offset(0);
        make.height.mas_equalTo(50);
    }];
    
    UIImageView*   line=[[UIImageView alloc]init];
    line.backgroundColor = RGB(200, 200, 200);
    [self.view addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_ProvincesStr.mas_bottom);
        make.height.mas_equalTo(0.5);
        make.left.right.mas_offset(0);
    }];
    
    UIImageView*  lineView=[[UIImageView alloc]init];
    lineView.userInteractionEnabled = YES;
    lineView.backgroundColor = [UIColor whiteColor];
    UITapGestureRecognizer *tapClick=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap_Click)];
    [lineView addGestureRecognizer:tapClick];
    [self.view addSubview:lineView];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(line.mas_bottom).offset(1);
        make.height.mas_equalTo(100);
        make.left.right.mas_offset(0);
    }];
    
    _detailView = [[UITextField alloc]init];
    _detailView.placeholder = @"详细地址";
    _detailView.backgroundColor = [UIColor whiteColor];
    _detailView.delegate = self;
    [lineView addSubview:_detailView];
    [_detailView mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.left.mas_offset(10);
        make.right.mas_offset(-10);
        make.height.mas_equalTo(15);
    }];
    
    UIImageView*   line2=[[UIImageView alloc]init];
    line2.backgroundColor = RGB(230, 230, 230);
    [self.view addSubview:line2];
    [line2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(lineView.mas_bottom);
        make.height.mas_equalTo(0.5);
        make.left.right.mas_offset(0);
    }];
    
    
    //设置默认按钮
    UIButton* delegateButton = [UIButton buttonWithType:UIButtonTypeCustom];
    delegateButton.backgroundColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.10];
    delegateButton.selected = _isDefault;
    
    UILabel *szkLabel=[[UILabel alloc]init];
    commonLabel = szkLabel;
    szkLabel.text=@"设为默认地址";
    szkLabel.textAlignment=NSTextAlignmentCenter;
    szkLabel.backgroundColor=[UIColor clearColor];
    [delegateButton addSubview:szkLabel];
    [szkLabel mas_makeConstraints:^(MASConstraintMaker *make){
        make.left.mas_offset(10);
        make.centerY.equalTo(delegateButton);
        make.width.mas_equalTo(100);
    }];
    
    imgArrow=[[UIImageView alloc]init];
    imgArrow.backgroundColor = [UIColor clearColor];
    imgArrow.image = [UIImage imageNamed:@"Car_on"];
    [delegateButton addSubview:imgArrow];
    [imgArrow mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(delegateButton);
        make.right.equalTo(delegateButton).offset(-5);
        make.width.mas_equalTo(30);
        make.height.mas_equalTo(30);
    }];
    
    [delegateButton addTarget:self action:@selector(deleBtnClcik:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:delegateButton];
    [delegateButton mas_makeConstraints:^(MASConstraintMaker *make){
        make.top.equalTo(lineView.mas_bottom).offset(10);
        make.left.right.mas_offset(0);
        make.height.mas_equalTo(50);
    }];
    
    
}
-(void)deleBtnClcik:(UIButton*)btn{
    btn.selected=!btn.selected;
}
-(void)tap_Click{
    [_detailView becomeFirstResponder];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
-(BOOL)textField:(UITextField*)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    NSString * toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    if(textField==_name.editField){
        if ([toBeString length]>10) {
            return NO;
        }
    }else if (textField==_phone.editField){
        if ([toBeString length]>11) {
            return NO;
        }
    }else if (textField==_detailView){
        
        [detailLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(40);
        }];
        
        if ([toBeString length]>50){
            return NO;
        }
    }
    
    return YES;
}
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    [self.view endEditing:YES];
    
}
//传入字符串、字体大小 返回高度
-(CGFloat)getLabelHeightWithStr:(NSString*)textStr font:(UIFont*)font height:(CGFloat)height width:(CGFloat)width{
    CGRect frame = [textStr boundingRectWithSize:CGSizeMake(width,height) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:font}context:nil];
    CGFloat resultHeight = frame.size.height;
    return resultHeight;
}
-(void)rightBarItem_Click{
    [[UIApplication sharedApplication] sendAction:@selector(resignFirstResponder) to:nil from:nil forEvent:nil];//隐藏键盘
    [self addAddressWithIsDefault:@"1"];
}
-(void)addAddressWithIsDefault:(NSString*)isDefaultStr{
    if(!(_name.editField.text.length>0)){
        [self showToastWithText:@"请填写收货人"];
        return;
    }
    if(!(_phone.editField.text.length>10)){
        [self showToastWithText:@"请填写正确手机号"];
        return;
    }
    if([_ProvincesStr.submit isEqualToString:@"选择地区"]){
        [self showToastWithText:@"请选择地区"];
        return;
    }
    if(!(_detailView.text.length>0)){
        [self showToastWithText:@"请填写详细地址"];
        return;
    }
    
    AVObject *todo = [AVObject objectWithClassName:@"Address"];
    [todo setObject:_countyId forKey:@"countyId"];
    [todo setObject:_communityId forKey:@"communityId"];
    [todo setObject:_name.editField.text forKey:@"name"];
    [todo setObject:_phone.editField.text forKey:@"phone"];
    [todo setObject:_ProvincesStr.submit forKey:@"ProvincesStr"];
    [todo setObject:_detailView.text forKey:@"detail"];
    
    [todo saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        [MBProgressHUD stopLoadding];
        if (succeeded) {
            [self showToastWithText:@"保存成功"];
            [self.navigationController popViewControllerAnimated:YES];
        } else {
            [self showToastWithText:@"保存失败"];
        }
    }];
}
-(void)updateAddressWithIsDefault{
    
}
@end
