//
//  CarTableViewCell.m
//  TomatoBaby
//
//  Created by ios on 2018/11/20.
//  Copyright © 2018年 ios. All rights reserved.
//

#import "CarTableViewCell.h"

@implementation CarTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    UITapGestureRecognizer* tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapClick:)];
    [_iconView addGestureRecognizer:tap];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setModel:(AVObject *)model{
    _model = model;
     NSString *strimage=_model[@"goodsIcon"];
    [_iconView sd_setImageWithURL:[NSURL URLWithString:strimage] placeholderImage:[UIImage imageNamed:@"icon_Default_headProtrait"]];
     _specificaLabel.text = [NSString stringWithFormat:@"%@kg",_model[@"goodsWeight"]];
    _pnameLabel.text = _model[@"goodsName"];
    _priceLabel.text = [NSString stringWithFormat:@"¥%@",_model[@"goodsPrice"]];
    _numLabel.text = _model[@"goodsNums"];

}
- (IBAction)selectBtn:(UIButton *)sender {

   
}

- (IBAction)addBtn:(UIButton *)sender {
    __weak typeof(self)WSelf = self;
    NSInteger nums = [_model[@"goodsNums"] integerValue];
    [AVQuery doCloudQueryInBackgroundWithCQL:[NSString stringWithFormat:@"update GoodsCar set goodsNums='%ld' where objectId='%@'",++nums,_model[@"objectId"]] callback:^(AVCloudQueryResult *result, NSError *error) {
        if(!error) {
            [WSelf.manager addGoodsNums:WSelf.model];
        }
    }];
}
- (IBAction)lessBtn:(UIButton *)sender {
    __weak typeof(self)WSelf = self;
    NSInteger nums = [_model[@"goodsNums"] integerValue];
    if (nums<2) {
        [MBProgressHUD showError:@"不能再少了!"];
        return;
    }
    [AVQuery doCloudQueryInBackgroundWithCQL:[NSString stringWithFormat:@"update GoodsCar set goodsNums='%ld' where objectId='%@'",--nums,_model[@"objectId"]] callback:^(AVCloudQueryResult *result, NSError *error) {
        if (!error) {
            [WSelf.manager deleteGoodsNums:_model];
        }
    }];
}
- (IBAction)delegateBtn:(UIButton *)sender {
    __weak typeof(self)WSelf = self;
    //delete from product_car where objectId='5ce861b87b968a0076421a5f'
    //delete from product_car where objectId='5ce8ff1ba673f50068faa770'
    
    [AVQuery doCloudQueryInBackgroundWithCQL:[NSString stringWithFormat:@"delete from GoodsCar where objectId='%@'",_model[@"objectId"]] callback:^(AVCloudQueryResult *result, NSError *error) {
        if (!error) {
             [WSelf.manager deleteGoods:_model];
        }else{
            [MBProgressHUD showError:@"操作失败"];
        }
    }];
}
-(void)tapClick:(UITapGestureRecognizer*)tap{
    [self.manager jumpToDetailWhenTapIconViewModel:_model];
}
@end
