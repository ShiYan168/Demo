//
//  CarTableViewCell.h
//  TomatoBaby
//
//  Created by ios on 2018/11/20.
//  Copyright © 2018年 ios. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol ShopingCarCellDelegate
- (void)addGoodsNums:(AVObject*)goodsModel;//数量+1
- (void)deleteGoodsNums:(AVObject*)goodsModel;//数量-1
- (void)selectGoods:(AVObject*)goodsModel;//select Goods
- (void)deleteGoods:(AVObject*)goodsModel;//delete Goods
-(void)jumpToDetailWhenTapIconViewModel:(AVObject*)model;//点击图片进详情
@end

@interface CarTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property(nonatomic,strong)AVObject* model;
@property (weak, nonatomic) IBOutlet UILabel *pnameLabel;
@property (weak, nonatomic) IBOutlet UILabel *specificaLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *numLabel;
@property (nonatomic,assign)NSInteger goodsNum;//商品数量
@property (nonatomic,weak)id<ShopingCarCellDelegate>manager;
@property (weak, nonatomic) IBOutlet UIButton *selectBtn;

@end

NS_ASSUME_NONNULL_END
