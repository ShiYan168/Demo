//
//  ShopCarViewController.m
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/24.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import "ShopCarViewController.h"
#import "CarTableViewCell.h"
#import "PayOrderController.h"

@interface ShopCarViewController ()<UITableViewDelegate,UITableViewDataSource,ShopingCarCellDelegate>
{
    UIButton* _rightButton;
    UILabel* _sums;
}
@property(nonatomic,strong)UITableView* tableView;
@property(nonatomic,strong)NSMutableArray* mutArr;
@property (nonatomic,strong)UIImageView *footView;

@end

@implementation ShopCarViewController
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.title = @"购物车";
        [self getCarListData];
        [_rightButton setTitle:@"清空" forState:UIControlStateNormal];
        _footView.hidden =NO;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _mutArr = [[NSMutableArray alloc] init];
    if (self.isShowLeftBtn) {
        [self setNavgationLeftItemBtn];
    }
    self.view.backgroundColor = [UIColor whiteColor];

    _rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _rightButton.titleLabel.font = [UIFont systemFontOfSize:14];
    _rightButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [_rightButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    _rightButton.frame = CGRectMake(0, 0, 40, 30);
    [_rightButton addTarget:self action:@selector(rightBarItem_Click) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:_rightButton];
    
    _tableView = [[UITableView alloc]init];
    _tableView.rowHeight = UITableViewAutomaticDimension;
    _tableView.estimatedRowHeight = 100;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.backgroundColor = [UIColor whiteColor];
    _tableView.showsVerticalScrollIndicator = NO;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableFooterView = [UIImageView new];
    [_tableView setLayoutMargins:UIEdgeInsetsZero];//分割线
    [self.view addSubview:_tableView];

    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.mas_offset(0);
        make.bottom.mas_offset(-88);
    }];
    
    [self.view addSubview:self.footView];
    [_footView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_offset(0);
        make.bottom.mas_offset(-44);
        make.top.mas_equalTo(_tableView.mas_bottom);
    }];
    
}
-(void)getCarListData{
    [MBProgressHUD startLoadding];
    AVQuery *query = [AVQuery queryWithClassName:@"GoodsCar"];
   
    [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
         [MBProgressHUD stopLoadding];
        if (!error) {
            [_mutArr removeAllObjects];
            [_mutArr addObjectsFromArray:objects];
            [_tableView reloadData];
            [self calcTotalAccountAndCounts];
            if (_mutArr.count>0) {
                _footView.hidden =NO;
            }else{
                _footView.hidden =YES;
            }
        }
    }];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _mutArr.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CarTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CarTableViewCell"];
    
    if (!cell){
        cell= [[[NSBundle  mainBundle]  loadNibNamed:@"CarTableViewCell" owner:self options:nil]  lastObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;//选中状态下颜色为透明色
        [tableView registerNib:[UINib nibWithNibName:@"CarTableViewCell" bundle:nil] forCellReuseIdentifier:@"CarTableViewCell"];
    }
    __weak typeof(self)wself = self;
    cell.manager = wself;
    cell.model = (AVObject*)_mutArr[indexPath.row];
    return cell;
}

- (void)addGoodsNums:(AVObject*)goodsModel{
    [self getCarListData];
}//数量+1
- (void)deleteGoodsNums:(AVObject*)goodsModel{
    [self getCarListData];
}//数量-1
- (void)deleteGoods:(AVObject*)goodsModel{
    [self getCarListData];
}//delete Goods

- (void)selectGoods:(AVObject*)goodsModel{
    [self getCarListData];
}
-(void)jumpToDetailWhenTapIconViewModel:(AVObject*)model{
   
}//点击图片进详情

-(void)rightBarItem_Click{
    if ([_rightButton.titleLabel.text isEqualToString:@"清空"]) {
        __weak typeof(self)wself=self;
        if (!(_mutArr.count>0)) {
            [self showToastWithText:@"购物车暂无数据"];
            return;
        }
            [AVObject deleteAllInBackground:_mutArr block:^(BOOL succeeded, NSError * _Nullable error) {
                [wself getCarListData];
            }];
 
    }
}

-(UIImageView*)footView{
    if (!_footView){
        _footView = [[UIImageView alloc]init];
        _footView.userInteractionEnabled = YES;
        _footView.backgroundColor = [UIColor whiteColor];
        UILabel* teml = [[UILabel alloc] init];
        teml.text = @"合计:";
        teml.font = [UIFont systemFontOfSize:18];
        [_footView addSubview:teml];
        [teml mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(_footView);
            make.left.mas_offset(10);
        }];
        
        _sums = [[UILabel alloc] init];
        _sums.font = [UIFont systemFontOfSize:17];
        [_footView addSubview:_sums];
        [_sums mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(_footView);
            make.left.mas_equalTo(teml.mas_right);
        }];
        
        
        UIButton* payBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        payBtn.backgroundColor = TBBaseColor;
        [payBtn setTitle:@"去结算" forState:UIControlStateNormal];
        [payBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [payBtn addTarget:self action:@selector(payBtnClick) forControlEvents:UIControlEventTouchUpInside];
        [_footView addSubview:payBtn];
        [payBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.mas_offset(0);
            make.right.mas_offset(0);
            make.width.mas_equalTo(T_WIDTH(120));
        }];
    }
    return _footView;
}
-(void)calcTotalAccountAndCounts{
    CGFloat sums = 0.00;
    for (AVObject* obj in _mutArr) {
        CGFloat price = [obj[@"goodsPrice"] floatValue];
        NSInteger nums = [obj[@"goodsNums"] integerValue];
        sums+=price*nums;
    }
    _sums.text = [NSString stringWithFormat:@"%.2f",sums];
}
-(void)payBtnClick{
    PayOrderController* payVc = [[PayOrderController alloc] init];
    payVc.goodsArr = _mutArr;
    payVc.sumsStr = _sums.text;
    payVc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:payVc animated:YES];
}
@end
