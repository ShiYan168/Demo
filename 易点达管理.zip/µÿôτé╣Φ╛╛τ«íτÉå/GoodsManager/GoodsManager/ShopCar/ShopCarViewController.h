//
//  ShopCarViewController.h
//  HBFrame
//
//  Created by HELLO WORLD on 2019/5/24.
//  Copyright © 2019年 guahibo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ShopCarViewController : UIViewController
@property(nonatomic,assign)BOOL isShowLeftBtn;
@end

NS_ASSUME_NONNULL_END
