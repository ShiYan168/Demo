//
//  ArtMacro.h
//  ArtistProject
//
//  Created by HELLO WORLD on 2017/3/5.
//  Copyright © 2017年 HELLO WORLD. All rights reserved.
//

#ifndef ArtMacro_h
#define ArtMacro_h

/* ArtMacro_h */
//#if DEBUG
//#define DLog(FORMAT, ...) fprintf(stderr,"\nLog:%s on line:%d \n-->%s", __FUNCTION__, __LINE__, [[NSString stringWithFormat:FORMAT, ##__VA_ARGS__] UTF8String]);
//#else
//#define ARTLog(FORMAT, ...) nil
//#endif


#ifdef DEBUG

#define JpushIsProduction NO
#define DLog(fmt, ...) NSLog((@"[文件名:%s]\n" "[函数名:%s]\n" "[行号:%d] \n" fmt), __FILE__, __FUNCTION__, __LINE__, ##__VA_ARGS__)

#else

#define JpushIsProduction YES
# define DLog(...)

#endif

#define TBReachability [ArtLoginData sharedManager].reachability
//-------------------获取设备大小-------------------------
//NavBar高度
#define NavigationBar_HEIGHT 44
#define StatusBar_HEIGHT 20

#define APPDELEGATE (AppDelegate*)[UIApplication sharedApplication].delegate

//获取屏幕 宽度、高度
#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)
#define KEY_WINDOW [[UIApplication sharedApplication]keyWindow]
#define TRUEW(v) (v*(SCREEN_WIDTH)/320)

//获取window
#define getWindow [[UIApplication sharedApplication] keyWindow]
//获取delegate
#define getDelegate [[UIApplication sharedApplication] delegate]

//获取指定View高度
#define getViewHeight(v) (v.frame.size.height+v.frame.origin.y)
#define getViewWidth(v) (v.frame.size.width+v.frame.origin.x)
#define T_WIDTH(v) (v*(SCREEN_WIDTH)/320)
#define T_HEIGHT(v) (v*(SCREEN_HEIGHT)/568)

CG_INLINE CGRect
CGRectMakeChange(CGFloat x, CGFloat y, CGFloat width, CGFloat height)
{
    //屏幕适配比例
    float autoSizeScaleX;
    float autoSizeScaleY;
    if (SCREEN_HEIGHT >480) {
        autoSizeScaleX = SCREEN_WIDTH/320;
        autoSizeScaleY = SCREEN_HEIGHT/568;
    } else {
        autoSizeScaleX = 1.0;
        autoSizeScaleY = 1.0;
    }
    
    
    CGRect rect;
    rect.origin.x = x * autoSizeScaleX;
    rect.origin.y = y * autoSizeScaleY;
    rect.size.width = width * autoSizeScaleX;
    rect.size.height = height * autoSizeScaleY;
    
    return rect;
}

#define UserDefaults    [NSUserDefaults standardUserDefaults]
#define IOSVersion     [[[UIDevice currentDevice] systemVersion] floatValue]

// 获取RGB颜色
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]
#define RGB(r,g,b) RGBA(r,g,b,1.0f)


//颜色转换
#define RGBCOLOR(r,g,b) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1]
#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)];

//清除背景色
#define CLEARCOLOR [UIColor clearColor]

//TB宏定义颜色
#define HEX_COLOR(x)    [UIColor colorWithHexString:(x)]

#define TBNavigation_COLOR RGB(250,250,250)
#define TBNavigationTitle_COLOR RGB(58,58,58)
#define TBCellLine_COLOR RGB(223,223,223)
#define TBViewBack_COLOR RGB(247,247,247)
#define TBCellSection_COLOR RGB(242,242,242)
#define TBCellBack_COLOR RGB(255,255,255)
#define TBBaseColor RGB(216,0,8)
#define TBBtnCommonColor RGB(204,204,204)
#define TBCellKeyTitle_COLOR RGB(158,158,158)
#define TBCellKeyAndValueTitle_COLOR RGB(88,88,88)
#define TBCellValueTitle_COLOR RGB(58,58,58)
#define TBRedTitle_COLOR RGB(216,0,8)
#define TBBlueTitle_COLOR RGB(28,133,247)
#define TBWhiteTitle_COLOR RGB(255,255,255)
#define TBBlackTitle_COLOR RGB(0,0,0)

#define k_color_gray_45 RGB(114,114,114)//45%灰
#define kTitleColor k_color_gray_45//[UIColor colorWithHexString:@"#333333"]
#define k_color_white RGB(255,255,255)//白

//TB宏定义字体
//PingFangSC-Ultralight  PingFangSC-Light
#define FONT_BUTTON_TITLE 15
#define FONT_CELL_TITLE 14

#define ART_FONT(F) [UIFont systemFontOfSize:F]
#define TBFONT_CELL_TITLE 14
#define TBPointThanOne 1
#define TBPointThanTwo 2

#define  UIFONT12 [UIFont systemFontOfSize:12]
#define  UIFONT13 [UIFont systemFontOfSize:13]
#define  UIFONT14 [UIFont systemFontOfSize:14]
#define  UIFONT15 [UIFont systemFontOfSize:15]
#define  UIFONT16 [UIFont systemFontOfSize:16]
#define  UIFONT17 [UIFont systemFontOfSize:17]
#define  UIFONT18 [UIFont systemFontOfSize:18]
#define  UIFONT19 [UIFont systemFontOfSize:19]
#define  UIFONT20 [UIFont systemFontOfSize:20]
#define  UIFONT21 [UIFont systemFontOfSize:21]
#define  UIFONT22 [UIFont systemFontOfSize:22]
#define  UIFONT23 [UIFont systemFontOfSize:23]
#define  UIFONT24 [UIFont systemFontOfSize:24]
#define  UIFONT25 [UIFont systemFontOfSize:25]


#endif /* TomatoUrl_h */


