//
//  AppMacros.h
//  FMall
//
//  Created by HELLO WORLD on 2019/4/23.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#ifndef AppMacros_h
#define AppMacros_h

#define AppLikeBagTable (@"LikeBag")
#define AppDayNewTable (@"DayNew")
#define AppBoyBagTable (@"BoyBag")
#define AppGirlBagTable (@"GirlBag")
#define AppGuessLikeTable (@"GuessLike")

// -------------------------------------------------    颜色定义开始  -------------------------------//
// 获取RGB颜色
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]
#define RGB(r,g,b) RGBA(r,g,b,1.0f)

#define COLOR(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]
#define GRAYCOLOR(c) COLOR(c,c,c)
#define ColorWithAlpha(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define UIColorFromRGBValue(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
#define RandomColorWithAlpha(a) [UIColor colorWithRed:arc4random_uniform(255)/255.0 green:arc4random_uniform(255)/255.0 blue:arc4random_uniform(255)/255.0 alpha:a]

//通用视觉规范
#define FSWhiteColor COLOR(255, 255, 255)          //纯白
#define FSBlueColor COLOR(0, 153, 255)             //蓝色
#define FSOrangeColor COLOR(253, 106, 60)          //橙色
#define FSYellowColor COLOR(239, 166, 68)          //黄色
#define FSBlackColor COLOR(68, 68, 68)             //浅黑色
#define FSGrayColor COLOR(102, 102, 102)           //灰色
#define FSlightGrayColor COLOR(153, 153, 153)      //浅灰色
#define FSCoffeeColor COLOR(185,152,99)            //咖啡色
#define FSCommonBgColor  COLOR(248, 248, 248)      //灰白色

#define FSSeparatorLineColor COLOR(232, 232, 232)  //分割线颜色
#define FSTranslucentColor ColorWithAlpha(0,0,0,0.55)  //半透明颜色

#define T_WIDTH(v) (v*(SCREEN_WIDTH)/320)
#define T_HEIGHT(v) (v*(SCREEN_HEIGHT)/568)

//定义构造单例的宏
#define SharedInstanceInterfaceBuilder(ClassName) \
+ (instancetype)sharedInstance;

#define SharedInstanceBuilder(ClassName) \
+ (instancetype)sharedInstance\
{\
static dispatch_once_t onceToken;\
static ClassName* instance;\
dispatch_once(&onceToken, ^{\
instance = [[ClassName alloc] init];\
});\
return instance;\
}


//日志打印
#if isDevelopModel
#define FSLog(...) NSLog(__VA_ARGS__);NSLog(@"Function is: %s line at: %d" ,__PRETTY_FUNCTION__, __LINE__)
#else
#define FSLog(...) ((void)0)
#endif

//拨打电话
#define makeCall(phoneNumber) [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",phoneNumber]]];

//tableView 分割线左边距归零
#define clearTableViewSeparator \
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath\
{\
if ([cell respondsToSelector:@selector(setSeparatorInset:)]){\
[cell setSeparatorInset:UIEdgeInsetsZero];\
}\
if ([cell respondsToSelector:@selector(setLayoutMargins:)]){\
[cell setLayoutMargins:UIEdgeInsetsZero];\
}\
}

#define setTableViewSeparatorZeroMargin(_tableView) \
if ([_tableView respondsToSelector:@selector(setSeparatorInset:)]){\
[_tableView setSeparatorInset:UIEdgeInsetsZero];\
}\
if ([_tableView respondsToSelector:@selector(setLayoutMargins:)]){\
[_tableView setLayoutMargins:UIEdgeInsetsZero];\
}

#endif /* AppMacros_h */
