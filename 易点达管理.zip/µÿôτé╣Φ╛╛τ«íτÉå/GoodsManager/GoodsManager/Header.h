//
//  Header.h
//  GoodsManager
//
//  Created by HELLO WORLD on 2019/6/1.
//  Copyright © 2019年 HELLO WORLD. All rights reserved.
//

#ifndef Header_h
#define Header_h

#define AppOnOff (@"2")
#define AppLikeBagTable (@"LikeBag")


#define UserDefaults    [NSUserDefaults standardUserDefaults]
#define IOSVersion     [[[UIDevice currentDevice] systemVersion] floatValue]

//获取屏幕 宽度、高度
#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)
#define KEY_WINDOW [[UIApplication sharedApplication]keyWindow]
#define TRUEW(v) (v*(SCREEN_WIDTH)/320)

// 获取RGB颜色
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]
#define RGB(r,g,b) RGBA(r,g,b,1.0f)
#define GMBaseColor RGB(0,0,0)

//通用视觉规范
#define GMWhiteColor RGB(255, 255, 255)          //纯白
#define GMBlueColor RGB(0, 153, 255)             //蓝色
#define GMOrangeColor RGB(253, 106, 60)          //橙色
#define GMYellowColor RGB(239, 166, 68)          //黄色
#define GMBlackColor RGB(68, 68, 68)             //浅黑色
#define GMGrayColor RGB(102, 102, 102)           //灰色
#define GMlightGrayColor RGB(153, 153, 153)      //浅灰色
#define GMCoffeeColor RGB(185,152,99)            //咖啡色
#define GMCommonBgColor  RGB(248, 248, 248)      //灰白色

#define GMSeparatorLineColor RGB(232, 232, 232)  //分割线颜色
#define GMTranslucentColor ColorWithAlpha(0,0,0,0.55)  //半透明颜色


#endif /* Header_h */
