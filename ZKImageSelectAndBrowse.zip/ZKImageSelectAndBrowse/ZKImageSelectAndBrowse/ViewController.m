//
//  ViewController.m
//  ZKImageSelectAndBrowse
//
//  Created by HELLO WORLD on 2019/9/18.
//  Copyright © 2019年 WaterProofer. All rights reserved.
//

#import "ViewController.h"
#import <Masonry.h>
#import "ZKImageSelectView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    ZKImageSelectView* selectView = [[ZKImageSelectView alloc]init];
    selectView.maxNumberOfImage = 6;
    selectView.allowEdit = YES;
    [self.view addSubview:selectView];
    [selectView mas_makeConstraints:^(MASConstraintMaker* make) {
        make.width.mas_equalTo(self.view.mas_width);
        make.top.offset(100);
    }];
}
@end
