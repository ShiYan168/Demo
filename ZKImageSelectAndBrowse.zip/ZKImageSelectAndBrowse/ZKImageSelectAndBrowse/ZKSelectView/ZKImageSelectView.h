//
//  ZKImageSelectView.h
//  ZKImageSelectAndBrowse
//
//  Created by HELLO WORLD on 2019/9/18.
//  Copyright © 2019年 WaterProofer. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZKImageSelectView : UIImageView
//图片列表
@property (nonatomic, strong) NSMutableArray<UIImage*>* listImages;
//最多可选择的图片数
@property (nonatomic, readwrite) int maxNumberOfImage;
//是否允许编辑
@property (nonatomic, readwrite) BOOL allowEdit;
@property (nonatomic, readwrite) BOOL allowScroll;

@property (nonatomic, copy) void (^selectAddBtnCilck)(UIImage*);
@property (nonatomic, copy) void (^selectDelBtnCilck)(NSInteger);
@property (nonatomic, copy) void (^reloadHeight)(CGFloat);

@end

NS_ASSUME_NONNULL_END
